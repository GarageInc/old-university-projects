﻿namespace course_work_zd
{
    partial class FSetColorV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_change = new System.Windows.Forms.Button();
            this.tb_id = new System.Windows.Forms.TextBox();
            this.lb_id = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_change
            // 
            this.bt_change.Location = new System.Drawing.Point(133, 65);
            this.bt_change.Name = "bt_change";
            this.bt_change.Size = new System.Drawing.Size(117, 23);
            this.bt_change.TabIndex = 0;
            this.bt_change.Text = "Измененить цвет";
            this.bt_change.UseVisualStyleBackColor = true;
            this.bt_change.Click += new System.EventHandler(this.bt_change_Click);
            // 
            // tb_id
            // 
            this.tb_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_id.Location = new System.Drawing.Point(191, 17);
            this.tb_id.Name = "tb_id";
            this.tb_id.Size = new System.Drawing.Size(59, 26);
            this.tb_id.TabIndex = 1;
            this.tb_id.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_id_KeyDown);
            // 
            // lb_id
            // 
            this.lb_id.AutoSize = true;
            this.lb_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_id.Location = new System.Drawing.Point(22, 20);
            this.lb_id.Name = "lb_id";
            this.lb_id.Size = new System.Drawing.Size(136, 20);
            this.lb_id.TabIndex = 2;
            this.lb_id.Text = "Номер вершины:";
            // 
            // FSetColorV
            // 
            this.AcceptButton = this.bt_change;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(271, 100);
            this.Controls.Add(this.lb_id);
            this.Controls.Add(this.tb_id);
            this.Controls.Add(this.bt_change);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FSetColorV";
            this.ShowIcon = false;
            this.Text = "Установить цвет вершины";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_change;
        private System.Windows.Forms.TextBox tb_id;
        private System.Windows.Forms.Label lb_id;
    }
}