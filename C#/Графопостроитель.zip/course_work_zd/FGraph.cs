﻿//FGraph.cs
//Zubarevich D.A. 2.04.11
//last update 09.05.11
//The main window for visualization of graph

using System;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Reflection;

namespace course_work_zd
{
    public partial class FGraph : Form
    {
        public FGraph()
        {
            InitializeComponent();
            //указываем в какой директории искать файлы рисунков
            sfd_save.InitialDirectory = Application.StartupPath;
            ofd_open.InitialDirectory = Application.StartupPath;
            //Заводим пустой граф
            graph = new Graph();
            isNeedInvalidating = true;
        }
        //объект представляющий граф
        private static Graph graph;
        //флаг показывающий необходимость перерисовки
        public bool isNeedInvalidating { get; set; }
        //флажки необходимые для корректного передвижения  графа по форме
        private bool isCtrl = false, isShift = false,
            CanMove = false, blockNewMove = false, canAdd = true;
        //координаты для последнего положения мыши
        float lastX = 100, lastY = 100;
        //часть заголовока формы по умолчанию
        string initTitle = "Graph Bilder v 3.0 - ";
        //изменялся ли файл
        private bool isChange = false;
        //поток для плоской укладки
        private Thread FloatLayingThread;
        //форма управляющая плоской укладкой графа
        private FFloatLaying ManagedForm;
        //работа с выделением элемента графа и с контекстным меню
        private void FGraph_MouseClick(object sender, MouseEventArgs e)
        {
            Focus();
            //работа с выделением
            if (e.Button == MouseButtons.Left)
            {
                //Добавление ребер
                Vertex ver = graph.getVer(e);
                if (isShift && ver != null)
                {
                    graph.add_edge_to(ver);
                    return;
                }
                //выделение элементов графа
                graph.select(e, isCtrl);
                Invalidate();
            }
            //работа с контекстным меню
            else
            {
                //вызов контекстного меню для вершины
                Vertex ver = graph.getVerRight(e);
                if (ver != null)
                {
                    exchanger.ver = ver;
                    cms_vertex.Show(e.X, e.Y);
                }
                //или для графа
                else
                {
                    Edge edge = graph.getEdgeRight(e);
                    if (edge != null)
                    {
                        exchanger.edge = edge;
                        cms_edge.Show(e.X, e.Y);
                    }
                }
            }
        }

        //Добавление вершины 
        private void FGraph_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                isNeedInvalidating = false;
                if (graph.ver_count < 99)
                {
                    if (canAdd)
                        graph.add_vertex(e.X, e.Y);
                    lastX = e.X;
                    lastY = e.Y;
                    change();
                }
                else
                    MessageBox.Show("Достигнуто максимальное число вершин.");
                isNeedInvalidating = true;
                Invalidate();

            }
        }

        //передвижение графа
        private void FGraph_MouseMove(object sender, MouseEventArgs e)
        {
            graph.mouseX = e.X;
            graph.mouseY = e.Y;
            if (e.Button == MouseButtons.Left)
            {
                //если не можем двигать, выходим
                if (!CanMove || blockNewMove)
                {
                    canAdd = true;
                    return;
                }
                change();
                blockNewMove = true;
                canAdd = false;
                //вычисляем вектор  перемещения
                float dx = e.X - lastX;
                float dy = e.Y - lastY;
                //обновляем стартовую точку
                lastX = e.X;
                lastY = e.Y;
                graph.moveSelected(dx, dy);
                //перерисовываем форму
                Invalidate();
                blockNewMove = false;
            }
        }

        //говорим что не можем двигаться если клавиши поднята
        private void FGraph_MouseUp(object sender, MouseEventArgs e)
        {
            CanMove = false;
        }

        //Запоминание координат при нажатии клавиши мыши
        private void FGraph_MouseDown(object sender, MouseEventArgs e)
        {
            Focus();
            lastX = e.X;
            lastY = e.Y;
            if (!isShift)
                CanMove = graph.select(e, isCtrl);
        }

        //перерисовка формы
        private void FGraph_Paint(object sender, PaintEventArgs e)
        {
            graph.draw(e.Graphics, exchanger.dx, exchanger.dy, !floatLayingToolStripMenuItem.Enabled);
            if (isNeedInvalidating)
                Invalidate();
            //делаем прорисовку элементов управления на форме
            ms_menu.Refresh();
            pn_managed.Refresh();
            //обнуляем смещение картинки
            exchanger.dx = 0;
            exchanger.dy = 0;
        }

        //при нажитии кнопки выставлении необходимых флажков
        private void FGraph_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control)
                isCtrl = true;
            if (e.Shift)
                isShift = true;
            if (e.KeyData == Keys.Delete)
            {
                change();
                graph.deleteSelected();
                Invalidate();
            }
            if (e.KeyData == Keys.Enter)
                createGraphFromToolStripMenuItem_Click(null, null);
            if (e.KeyData == Keys.Up)
                bt_up_Click(null, null);
            if (e.KeyData == Keys.Down)
                bt_down_Click(null, null);
            if (e.KeyData == Keys.Left)
                bt_left_Click(null, null);
            if (e.KeyData == Keys.Right)
                bt_right_Click(null, null);

        }

        //снятие флажков при отпускании соответствующей кнопки
        private void FGraph_KeyUp(object sender, KeyEventArgs e)
        {
            if (!e.Control)
                isCtrl = false;
            if (!e.Shift)
                isShift = false; 
        }

        //выход
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        //новый граф
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph = new Graph();
            Text = initTitle + "noname.graph";
            Invalidate();
        }

        //добавление верщины
        private void addVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            if (graph.ver_count == 99)
            {
                MessageBox.Show("Достигнуто максимальное число вершин");
                return;
            }               
            graph.add_vertex(
                (lastX += Params.diameter) % (Width - pn_managed.Width * 2),
                (lastY += Params.diameter) % (Height - ms_menu.Height * 3));
            change();
            isNeedInvalidating = true;
            Invalidate();
        }

        //удаление выделенных вершин
        private void deleteSelectedVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.deleteSelectedVertices();
            change();
            Invalidate();
        }

        //удаление выделенных ребер
        private void deleteSelectedEdgesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.deleteSelectedEdges();
            change();
            Invalidate();
        }

        //удаление всего выделенного
        private void deleteAllSelectedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.deleteSelected();
            change();
            Invalidate();
        }

        //проверяем существование дуги, вес которой, пользователь хочет поменять
        public static bool checkChangeWeight(int i, int j, out Edge edge)
        {
            try
            {
                edge = graph[i, j];
                return edge != null ? true : false;
            }
            catch (ArgumentOutOfRangeException e)
            {
                edge = null;
                return false;
            }
        }

        //проверяем существование вершины, имя которой пользователь хочет изменить
        public static bool checkChangeName(int id, out Vertex ver)
        {
            try {
                ver = graph[id];
                return true;
            }
            catch (ArgumentOutOfRangeException e)
            {
                ver = null;
                return false;
            }
        }

        //установка веса дуги
        private void SetWeightOfEdgeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetWeight dialog = new FSetWeight();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                exchanger.edge.weight = exchanger.weight;
                change();
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка имени вершины
        private void SetNameOfVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetName dialog = new FSetName();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                exchanger.ver.data = exchanger.name;
                change();
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка цвета ребра
        private void setColorOfEdgeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetColor dialog = new FSetColor();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                
                if (cd_color_of_edge.ShowDialog() == DialogResult.OK)
                    exchanger.edge.color = cd_color_of_edge.Color;
                change();
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка цвета вершины
        private void setColorOfVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetColorV dialog = new FSetColorV();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                
                if (cd_color_of_edge.ShowDialog() == DialogResult.OK)
                {
                    exchanger.ver.color = cd_color_of_edge.Color;
                    change();
                }
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка имени вершины, по которой был произведён щелчок
        private void setNameOfThisVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetName dialog = new FSetName(exchanger.ver);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                exchanger.ver.data = exchanger.name;
                change();
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка веса дуги, по которой был произведён щелчок
        private void setWeightOfThisEdgeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            FSetWeight dialog = new FSetWeight(exchanger.edge);
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                exchanger.edge.weight = exchanger.weight;
                change();
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка цвета дуги, по которой был произведён щелчок
        private void setColorOfThisEdgeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            if (cd_color_of_edge.ShowDialog() == DialogResult.OK)
            {
                exchanger.edge.color = cd_color_of_edge.Color;
                change();
            }
            exchanger.edge.IsSelected = false;
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка цвета вершины, по которой был произведён щелчок
        private void setColorOfThisVertexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            if (cd_color_of_edge.ShowDialog() == DialogResult.OK)
            {
                exchanger.ver.color = cd_color_of_edge.Color;
                change();
            }
            exchanger.ver.IsSelected = false;
            isNeedInvalidating = true;
            Invalidate();
        }

        //установка вершин по кругу
        private void setVerticesOfTheCircleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.setOfCircle(Width, Height - ms_menu.Height * 3);
            change();
            Invalidate();
        }

        //выделение всех ребер
        private void selectAllEdgesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.select_edges();
            Invalidate();
        }

        //выделение всех вершин
        private void selectAllVerticesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.select_vertices();
            Invalidate();
        }

        //выделение всего графа
        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            graph.select_edges();
            graph.select_vertices();
            Invalidate();
        }

        //поиск всех путей м/у двумя вершинами
        private void searchOfPathesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FPathes path = new FPathes(graph);
            path.Show();
        }

        //вызов окошка с информацией о программе 
        private void aboutProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAbout form = new FAbout();
            form.ShowDialog();
        }

        //вызов справки
        private void manualToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FManual form = new FManual();
            form.Show();
        }

        //создать граф из указанного числа вершин
        private void createGraphFromToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            int count;
            if (int.TryParse(tstb_count.Text, out count))
            {
                if (count < 100 && count > 0)
                {
                    graph = new Graph(count, Width, Height - ms_menu.Height * 3 - pn_managed.Height);
                    Text = initTitle + "noname.graph";
                }
                else
                    MessageBox.Show("Количество вершин должно быть положительным числом меньше 100");
            }
            isNeedInvalidating = true;
            Invalidate();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            //если файл хотят открыть
            if (ofd_open.ShowDialog() == DialogResult.OK)
            {
                StreamReader f = null; 
                try
                {
                    //берём имя файла
                    string fname = ofd_open.FileName;
                    //создаем поток
                    f = new StreamReader(new FileStream(fname, FileMode.Open, FileAccess.Read, FileShare.None));
                    Graph temp = new Graph();
                    temp.read(f);
                    graph = temp;
                    //закрытие файла
                    f.Close();
                    // Изменение заголовка окна главной формы приложения
                    this.Text = initTitle + fname.Substring(fname.LastIndexOf('\\') + 1);
                    // Сброс флажка, указывающего на то, что сохраненный файл изменен!
                    isChange = false;
                }
                //ловим возможные ошибки
                catch (IOException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    //прорисовка формы
                    Invalidate();
                    if (f != null)
                        f.Close();
                }
            }
            isNeedInvalidating = true;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isNeedInvalidating = false;
            //если файл хотят сохранить
            if (sfd_save.ShowDialog() == DialogResult.OK)
            {
                //берём имя файла
                string fname = sfd_save.FileName;
                //создаём поток для записи в файл с данным именем 
                //с запретом доступа к нему других приложений в это время
                StreamWriter f = new StreamWriter(new FileStream(fname, FileMode.Create, FileAccess.Write, FileShare.None));
                //сохраняем данные
                graph.print(f);
                //закрываем файл
                f.Close();
                // Изменение заголовка окна главной формы приложения
                this.Text = initTitle + fname.Substring(fname.LastIndexOf('\\') + 1);
                // Сброс флажка, указывающего на то, что сохраненный файл изменен!
                isChange = false;
                //прорисовываем форму заново
                Invalidate();
            }
            isNeedInvalidating = true;
        }

        //установка звездочки
        private void change()
        {
            if (!isChange)
            {
                isChange = true;
                Text += "*";
            }
        }

        //прокрутка картинки графа
        private void bt_left_Click(object sender, EventArgs e)
        {
            exchanger.dx -= Params.d;
        }
        //прокрутка картинки графа
        private void bt_up_Click(object sender, EventArgs e)
        {
            exchanger.dy -= Params.d;
        }
        //прокрутка картинки графа
        private void bt_down_Click(object sender, EventArgs e)
        {
            exchanger.dy += Params.d;
        }
        //прокрутка картинки графа
        private void bt_right_Click(object sender, EventArgs e)
        {
            exchanger.dx += Params.d;
        }

        /////////////////////////////////
        //КОД ДЛЯ ПЛОСКОЙ УКЛАДКИ ГРАФА//
        /////////////////////////////////

        delegate void Changeable(bool canChange);

        //установка возможности изменения графа
        private void changeable(bool canChange)
        {
            commandsToolStripMenuItem.Enabled = 
            fileToolStripMenuItem.Enabled =
            createGraphFromToolStripMenuItem.Enabled =
            infoToolStripMenuItem.Enabled = canChange;
        }

        //точка входа для потока для укладки графа
        public void FloatLaying()
        {
            graph.FloatLaying(this, ManagedForm);
        }

        private void floatLayingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //снимаем выделение
            graph.unselect_all();
            //убираем возможность менять граф
            changeable(false);
            //заводим поток для плоской укладки
            FloatLayingThread = new Thread(FloatLaying);
            //Создаем управляющую форму и запускаем
            (ManagedForm = new FFloatLaying(this, graph, changeable, FloatLayingThread)).Show();
        }
    }
}
