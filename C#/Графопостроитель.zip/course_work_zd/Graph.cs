﻿//Graph.cs
//Zubarevich D.A. 2.04.11
//last update 13.05.11
//Work with graph is represented by this class 

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;

namespace course_work_zd
{
    public class Graph
    {
        //создание пустого графа
        public Graph()
        {
            ver_count = 0;
            edg_count = 0;
            vertices = new Dictionary<int, Vertex>();
            edges = new Dictionary<int, Edge>();
        }

        //создание графа с заданным числом вершин
        public Graph(int count, int width, int height)
        {
            ver_count = 0;
            edg_count = 0;
            vertices = new Dictionary<int, Vertex>();
            edges = new Dictionary<int, Edge>();
            for (int i = 0; i < count; i++)
                add_vertex(0, 0);
            this.setOfCircle(width, height);
        }

        //создание графа из матрицы смежности и массива координат вершин
        public Graph(int[,] matrix, int[,] coordinates)
        {
            ver_count = 0;
            edg_count = 0;
            vertices = new Dictionary<int, Vertex>();
            edges = new Dictionary<int, Edge>();
            int n = coordinates.Length / 2;
            for (int i = 0; i < n; i++)
                add_vertex(coordinates[i,0], coordinates[i,1]);
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    if (matrix[i, j] != 0)
                        add_edge(vertices[i], vertices[j], matrix[i,j]);
        }

        //генератор случайных чисел для веса ребер
        Random rand = new Random();
        //количество вершин
        public int ver_count { get; private set; }
        //количество ребер
        public int edg_count { get; private set; }
        //хэштаблица вершин
        Dictionary<int, Vertex> vertices;
        //хэштаблица ребер
        Dictionary<int, Edge> edges;
        //текущие координаты мыши
        public int mouseX { get; set; }
        public int mouseY { get; set; }
        //взятие вершины по идентификатору
        public Vertex this[int i] {
            get {
                if (vertices.ContainsKey(i))
                    return vertices[i];
                throw new ArgumentOutOfRangeException();
            }
        }
        //взятие ребра по вершинам
        public Edge this[Vertex i, Vertex j]
        {
            get
            {
                if (i.exit_edges.ContainsKey(j) && j.entry_edges.ContainsKey(i))
                {
                    Edge edge1 = i.exit_edges[j];
                    Edge edge2 = j.entry_edges[i];
                    return edge1 != null && edge2 != null ? edge1 : null;
                }
                throw new ArgumentOutOfRangeException();
            }
        }

        //взятие ребра по номерам вершин
        public Edge this[int i, int j] {
            get {
                if (vertices.ContainsKey(i) && vertices.ContainsKey(j)) {
                    Vertex v1 = vertices[i];
                    Vertex v2 = vertices[j];
                    if (v1.exit_edges.ContainsKey(v2) && v2.entry_edges.ContainsKey(v1))
                    {
                        Edge edge1 = v1.exit_edges[v2];
                        Edge edge2 = v2.entry_edges[v1];
                        return edge1 != null ? edge1 : (edge2 != null ? edge2 : null);
                    }
                }
                throw new ArgumentOutOfRangeException();
            }
        }

        //взятие ребра по идентификатору
        public Edge this[long i] {
            get {
                if (edges.ContainsKey((int)i)) {
                    return edges[(int)i];
                }
                throw new ArgumentOutOfRangeException();
            }
        }

        //добавление вершины с заданными координатами
        public void add_vertex(float x, float y)
        {
            Vertex new_ver = new Vertex(ver_count++, x, y);
            vertices.Add(new_ver.id, new_ver);
        }

        //добавление вершины
        public void add_vertex(Vertex ver)
        {
            ver.id = ver_count++;
            vertices.Add(ver.id, ver);
        }

        //добавление ребер из выделенных вершин к вершине ver
        public void add_edge_to(Vertex ver)
        {
            for (int i = 0; i < ver_count; i++)
            {
                Vertex current = vertices[i];
                if (current.IsSelected && !current.exit_edges.ContainsKey(ver))
                    add_edge(current, ver);
            }
        }

        //добавление ребра из вершины from к вершине to
        private void add_edge(Vertex from, Vertex to)
        {
            Edge newEdge = new Edge(edg_count++, from, to, rand.Next(1, 99));
            //добавление ссылок на ребро
            from.exit_edges.Add(to, newEdge);
            to.entry_edges.Add(from, newEdge);
            //добавление в хэштаблицу
            edges.Add(newEdge.id, newEdge);
        }

        //добавление ребра из вершины from к вершине to с весом weight
        private void add_edge(Vertex from, Vertex to, int weight)
        {
            Edge newEdge = new Edge(edg_count++, from, to, weight);
            //добавление ссылок на ребро
            from.exit_edges.Add(to, newEdge);
            to.entry_edges.Add(from, newEdge);
            //добавление в хэштаблицу
            edges.Add(newEdge.id, newEdge);
        }

        //добавление ребра
        private void add_edge(Edge edge)
        {
            edge.id = edg_count++;
            edges.Add(edge.id, edge);
        }

        //удаление ребра с данным идентификатором
        public void del_edge(int id)
        {
            try
            {
                //очистка ссылок на даное ребро
                edges[id].clean_vertices();
                edges.Remove(id);
                //уменьшение количества
                edg_count--;
                //если ребро не последнее в списке
                if (id != edg_count)
                {
                    //меняем идентификатор последнего
                    //на идентификатор удаленного
                    Edge temp = edges[edg_count];
                    temp.id = id;
                    edges.Remove(edg_count);
                    edges.Add(id, temp);
                }
            }
            catch (ArgumentOutOfRangeException e)
            {
                MessageBox.Show("Неправильный номер ребра!");
                edg_count++;
            }
        }

        public void del_vertex(int id)
        {
            try 
            {
                //очистка ссылок на даное ребро
                vertices[id].clean_edges(del_edge);
                vertices.Remove(id);
                //уменьшение количества
                ver_count--;
                //если вершина не последняя в списке
                if (id != ver_count)
                {
                    //меняем идентификатор последней вершины
                    //на идентификатор удаленной
                    Vertex temp = vertices[ver_count];
                    temp.id = id;
                    vertices.Remove(ver_count);
                    vertices.Add(id, temp);
                }
            }
            catch(ArgumentOutOfRangeException e) {
                MessageBox.Show("Неправильный номер вершины!");
                ver_count++;
            }
        }

        //удаление выделенных ребер
        public void deleteSelectedEdges()
        {
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                if (edge.IsSelected)
                {
                    //если удалено ребро
                    del_edge(edge.id);
                    //то другое ребро может получить его ид
                    //поэтому делаем проверку ещё раз
                    i--;
                }
            }
        }
        //удаление выделенных вершин
        public void deleteSelectedVertices()
        {
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                if (ver.IsSelected)
                {
                    //если удалена вершина
                    del_vertex(ver.id);
                    //то другая вершина может получить её ид
                    //поэтому делаем проверку ещё раз
                    i--;
                }
            }
        }

        //удаление всего, что выделено
        public void deleteSelected()
        {
            deleteSelectedVertices();
            deleteSelectedEdges();
        }

        //перерисовка графа
        public void draw(Graphics g, int dx, int dy, bool isLayingIsStarted)
        {
            //запоминаем смещение картинки
            exchanger.dx = dx;
            exchanger.dy = dy;
            //повышаем качество картинки
            g.SmoothingMode = SmoothingMode.HighQuality;
            //if (isLayingIsStarted)
            if (false)
            {
                //foreach (Graph graph in components)
                //    graph.draw(g, dx, dy, false);
            }
            else
            {
                //прорисовываем все вершины
                foreach (KeyValuePair<int, Vertex> pair in vertices)
                {
                    pair.Value.isAlreadyMove = false;
                    pair.Value.draw(g, mouseX, mouseY);
                }
                //прорисовываем все ребра
                foreach (KeyValuePair<int, Edge> pair in edges)
                    pair.Value.draw(g);
            }
        }

        //выделение ребер
        private bool select_edge(MouseEventArgs m, bool isCtrl)
        {
            //было ли что-то найдено
            bool isFound = false;
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                //если точка попадает на ребро и еще ничего не было найдено
                if (edge.isContain(m.X, m.Y) && !isFound)
                {
                    edge.IsSelected = true;
                    isFound = true;
                }
                else
                    //если ctrl не зажат то снимаем выделение
                    if (!isCtrl)
                        edge.IsSelected = false;
            }
            return isFound;
        }

        //выделение вершин
        private bool select_ver(MouseEventArgs m, bool isCtrl)
        {
            //было ли что-то найдено
            bool isFound = false;
            for(int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                //если точка попадает в вершину и еще ничего не было найдено
                if (ver.isContain(m.X, m.Y) && !isFound)
                {
                    ver.IsSelected = true;
                    isFound = true;
                }
                else
                    //если ctrl не зажат то снимаем выделение
                    if (!isCtrl)
                        ver.IsSelected = false;
            }
            return isFound;
        }

        //выделение ребер и вершин
        public bool select(MouseEventArgs m, bool isCtrl)
        {
            bool a = select_ver(m, isCtrl);
            bool b = select_edge(m, isCtrl);
            return a || b;         
        }

        //двигаем выделенные вершины 
        private void move_selected_ver(float dx, float dy)
        {
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                if (ver.IsSelected)
                    ver.move(dx, dy);
            }
        }

        //двигаем выделенные ребра
        private void move_selected_edge(float dx, float dy)
        {
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                if (edge.IsSelected)
                    edge.move(dx, dy);
            }
        }

        //двигаем выделенны ребра и вершины
        public void moveSelected(float dx, float dy)
        {
            move_selected_ver(dx, dy);
            move_selected_edge(dx, dy);
        }

        //берем невыделенное ребро по точке
        public Edge getEdge(MouseEventArgs m)
        {
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                if (edge.isContain(m.X, m.Y) && !edge.IsSelected)
                    return edge;
            }
            return null;
        }

        //берем невыделенную вершину по точке
        public Vertex getVer(MouseEventArgs m)
        {
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                if (ver.isContain(m.X, m.Y) && !ver.IsSelected)
                    return ver;
            }
            return null;
        }

        //берем любое ребро по точке
        public Edge getEdgeRight(MouseEventArgs m)
        {
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                if (edge.isContain(m.X, m.Y))
                    return edge;
            }
            return null;
        }

        //берем любую вершину по точке
        public Vertex getVerRight(MouseEventArgs m)
        {
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                if (ver.isContain(m.X, m.Y))
                    return ver;
            }
            return null;
        }

        //устанавливаем вершины по кругу
        public void setOfCircle(int width, int height)
        {
            width -= (int)Params.ver_width;
            height -= (int)Params.ver_height;
            if (ver_count == 0)
                return;
            float radius = Math.Min(width, height) / 2;
            float d_angle = 2 * (float)Math.PI / ver_count;
            float x0 = width / 2;
            float y0 = height / 2 + Params.ver_height * 2;
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                float angle = i * d_angle;
                ver.x = x0 + radius * (float)Math.Cos(angle);
                ver.y = y0 + radius * (float)Math.Sin(angle);
            }

        }

        //выделяем все ребра
        public void select_edges()
        {
            for (int i = 0; i < edg_count; i++)
                edges[i].IsSelected = true;
        }

        //выделяем все вершины
        public void select_vertices()
        {
            for (int i = 0; i < ver_count; i++)
                vertices[i].IsSelected = true;
        }

        //снимаем выделение
        public void unselect_all()
        {
            //снимаем выделение
            for (int i = 0; i < ver_count; i++)
                vertices[i].IsSelected = false;
            for (int i = 0; i < edg_count; i++)
                edges[i].IsSelected = false;
        }

        //получение представления графа в виде матрицы смежности
        public int[,] toMatrix()
        {
            int[,] matrix = new int[ver_count, ver_count];
            for (int i = 0; i < ver_count; i++)
                for (int j = 0; j < ver_count; j++)
                    matrix[i, j] = -1;
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                foreach (KeyValuePair<Vertex, Edge> pair in ver.exit_edges)
                {
                    Edge edge = pair.Value;
                    matrix[ver.id, edge.end.id] = edge.weight;
                }
                foreach (KeyValuePair<Vertex, Edge> pair in ver.entry_edges)
                {
                    Edge edge = pair.Value;
                    matrix[edge.start.id, ver.id] = edge.weight;
                }
            }
            return matrix;
        }

        //печать графа в поток
        public void print(StreamWriter sw)
        {
            sw.WriteLine("Количество вершин в графе:");
            sw.WriteLine(ver_count.ToString());
            sw.WriteLine(@"Информация о вершинах в формате:
Номер вершины
Имя
Цвет
Координата x
Координата у");
            //Печатаем информацию о вершинах
            for (int i = 0; i < ver_count; i++)
            {
                Vertex ver = vertices[i];
                sw.WriteLine((ver.id + 1).ToString());
                sw.WriteLine((string)ver.data);
                sw.WriteLine((ver.color.ToArgb()).ToString());
                sw.WriteLine(ver.x.ToString());
                sw.WriteLine(ver.y.ToString());
                sw.WriteLine("________________");
            }
            sw.WriteLine("Количество ребер в графе:");
            sw.WriteLine(edg_count.ToString());
            sw.WriteLine(@"Информация о ребрах в формате:
Номер начальной вершины 
Номер конечной вершины
Цвет");
            //Печатаем информацию о ребрах
            for (int i = 0; i < edg_count; i++)
            {
                Edge edge = edges[i];
                sw.WriteLine((edge.start.id + 1).ToString());
                sw.WriteLine((edge.end.id + 1).ToString());
                sw.WriteLine((edge.color.ToArgb()).ToString());
                sw.WriteLine("________________");
            }
            sw.WriteLine(@"
Матрица смежности графа:
");
            //печатаем матрицу смежности
            int[,] matrix = toMatrix();
            string res;
            for (int i = 0; i < ver_count; i++)
            {
                res = null;
                for (int j = 0; j < ver_count; j++)
                    res += (matrix[i, j] + " ");
                sw.WriteLine(res);
            }
        }

        //чтение графа из файла
        public void read(StreamReader f)
        {
            //чтение информации о вершинах
            f.ReadLine();
            int count;
            if (!int.TryParse(f.ReadLine(), out count))
                throw new IOException("Неизвестно количество вершин");
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            for (int i = 0; i < count; i++)
            {
                int id;
                if (!int.TryParse(f.ReadLine(), out id))
                    throw new IOException("Неправильное хранение идентификаторов вершин");
                id--;
                string data = f.ReadLine();
                int color;
                if (!int.TryParse(f.ReadLine(), out color))
                    throw new IOException("Неправильное значение цвета");
                float x;
                if (!float.TryParse(f.ReadLine(), out x))
                    throw new IOException("Неправильное хранение координаты х");
                float y;
                if (!float.TryParse(f.ReadLine(), out y))
                    throw new IOException("Неправильное хранение координаты у");
                Vertex ver = new Vertex(id, data, x, y);
                ver.color = Color.FromArgb(color);
                vertices.Add(id, ver);
                ver_count++;
                f.ReadLine();
            }
            //чтение информации о ребрах
            f.ReadLine();
            int countVertex = count;
            if (!int.TryParse(f.ReadLine(), out count))
                throw new IOException("Неизвестно количество ребер");
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            for (int i = 0; i < count; i++)
            {
                int id_start;
                if (!int.TryParse(f.ReadLine(), out id_start))
                    throw new IOException("Неправильное хранение идентификаторов ребер");
                id_start--;
                int id_end;
                if (!int.TryParse(f.ReadLine(), out id_end))
                    throw new IOException("Неправильное хранение идентификаторов ребер");
                id_end--;
                int color;
                if (!int.TryParse(f.ReadLine(), out color))
                    throw new IOException("Неправильное значение цвета");
                add_edge(vertices[id_start], vertices[id_end]);
                this[id_start, id_end].color = Color.FromArgb(color);
                f.ReadLine();
            }
            f.ReadLine();
            f.ReadLine();
            f.ReadLine();
            //Установка весов ребер из матрицы смежности
            int[,] matrix = new int[countVertex, countVertex];
            char sep = ' ';
            for (int j = 0; j < countVertex; j++)
            {
                string str = f.ReadLine();
                string[] weight = str.Split(sep);
                for (int i = 0; i < countVertex; i++)
                {
                    if (!int.TryParse(weight[i], out matrix[j, i]))
                        throw new IOException("неправильное хранение веса");
                    if (matrix[j, i] != -1)
                        this[j, i].weight = matrix[j, i];
                }
            }
        }

        /////////////////////////////////
        //КОД ДЛЯ ПЛОСКОЙ УКЛАДКИ ГРАФА//
        /////////////////////////////////

        //делегат для изменения элемента управления control методом method
        delegate void Change(Control control, string method);

        //изменение элемента управления из другого потока
        private void change(Control control, string method)
        {
            //если вызов из второго потока
            if (control.InvokeRequired)
                //запускаемся из основного потока
                mainForm.Invoke(new Change(change), new object[] { control, method });
            else
                //иначе просто выполняем метод
                control.GetType().GetMethod(method).Invoke(control, null);
        }

        public void sleep()
        {
            //перерисовываем форму
            change(mainForm, "Refresh");
            //даем пользователю полюбоваться результатом
            System.Threading.Thread.Sleep(Params.sleep);
        }

        //смотрим не посещали ли ещё эту вершину
        private void getNextVertices(KeyValuePair<Vertex, Edge> pair, int startIndex)
        {
            Edge edge  = pair.Value;
            //отмечаем ребро, по которому пришли
            edge.IsSelected = true;
            //если есть противоположное данному ребро
            if (edge.end.exit_edges.ContainsKey(edge.start))
                components[counter - 1].EdgeCount += 0.25F;
            else
                components[counter - 1].EdgeCount += 0.5F;
            //демонстрируем пользователю
            sleep();
            Vertex ver = pair.Key;
            //если попали в отмеченную вершину
            if (markers[ver.id])
                //выходим
                return;
            //иначе запускаем дальнецшее построение компоненты
            getOneComponent(ver.id);
        }

        //получаем компоненту связности содержащую данную вершину
        private void getOneComponent(int startIndex)
        {
            //помечаем вершину как отработанную
            markers[startIndex] = true;
            //заносим в соответствующую компоненту
            components[counter - 1].vertices.Add(startIndex);
            components[counter - 1].VerCount++;
            //уменьшаем число не помеченных вершин
            countOfNonMarkedVertex--;
            //Берем вершину
            Vertex start = vertices[startIndex];
            //выделяем её
            start.IsSelected = true;
            //ждем пока пользователь на это посмотрит
            sleep();
            //перебираем все инцидентные вершины не обращая 
            //внимания на направление ребер
            foreach (KeyValuePair<Vertex, Edge> pair in start.entry_edges)
                getNextVertices(pair, startIndex);
            foreach (KeyValuePair<Vertex, Edge> pair in start.exit_edges)
                getNextVertices(pair, startIndex);
        }
        
        //разделение графа на компоненты связности
        private List<Component> getComponentsCoherency()
        {
            managedForm.setText("Запускаем обход графа.");
            //массив для отметок вершин
            markers = new bool[ver_count];
            //счетчик для компонент
            counter = 0;
            //количество неотмеченных вершин
            countOfNonMarkedVertex = ver_count;
            //заводим список компонент
            components = new List<Component>(counter);
            //пока есть неотмеченнные вершины
            while (countOfNonMarkedVertex != 0)
            {
                managedForm.setText("Есть неотмеченная вершина. Строим компоненту, посещая вершины, которые соединены путем с этой неотмеченной вершиной. ");
                //находим номер неотмеченной вершины
                int i = 0;
                for (; i < ver_count; i++)
                    if (markers[i] == false)
                        break;
                //добавляем компоненту к списку компонент
                components.Add(new Component());
                //нрасчиваем количество компонент
                counter++;
                //строим компоненту
                getOneComponent(i);
                managedForm.setText("Компонента построена. (Выделена красным на рисунке)");
                sleep();
                //снимаем выделение
                unselect_all();
                sleep();
            }
            managedForm.setText("Клоличество компонент графа: " + counter.ToString());
            return components;
        }

        class Component
        {
            public List<int> vertices { get; set; }
            public int VerCount { get; set; }
            public float EdgeCount { get; set; }
            public float MaxX { get; set; }
            public float MaxY { get; set; }
            public float MinX { get; set; }
            public float MinY { get; set; }


            public Component()
            {
                vertices = new List<int>();
                VerCount = 0;
                EdgeCount = 0;
                MaxX = 0;
                MaxY = 0;
                MinX = 0;
                MinY = 0;
            }
        }


        //список компонент
        private List<Component> components;
        //отметки вершин
        private bool[] markers;
        //форма, на которой идет отрисовка графа
        private FGraph mainForm;
        //форма, управляющая алгоритмом укладки
        private FFloatLaying managedForm;
        //количество компонент
        private int counter;
        //количество неотмеченных вершин
        int countOfNonMarkedVertex;

        delegate void Signal();

        //метод для плоской укладки
        public void FloatLaying(FGraph main_form, FFloatLaying managed_form)
        {
            //записываем сведения о формах
            mainForm = main_form;
            managedForm = managed_form;

            managedForm.setText("Этап 1. Определяем компоненты свзяности графа.");
            //бьем на компоненты
            components = getComponentsCoherency();
            managedForm.setText("Все компоненты связности определены. Теперь будем работать с каждой компонентой отдельно");
           
            managedForm.setText("Этап 2. Укладка по одной компоненте свзяности графа.");
            //укладка компонент в цикле
            for (int i = 0; i < counter; i++)
            {
                managedForm.setText("укладываем " + (i + 1).ToString() + "-ю из определенных компонент.");
                layingOfComponent(components[i]);
            }
            //сообщаем о завершении
            mainForm.Invoke(new Signal(managedForm.SignalAboutEnd));
        }

        //укладываем одну компоненту
        private void layingOfComponent(Component component)
        {
            int difference = component.VerCount - (int)component.EdgeCount;
            managedForm.setText("Считаем граф неориентированным. Тогда: Количество вершин - количества ребер = " + difference.ToString());
            //проверяем не является ли компонента деревом
            if (difference == 1)
            {
                //если компонента дерево, тогда просто укладываем дерево
                managedForm.setText("Значит компонента является деревом. Дерево - планарный граф. Проводим укладку");
                FloatLayingOfTree(component, 0, 0);
            }
            else
            {
                //ищем мост
                managedForm.setText("Ищем мост в компоненте");
                Edge bridge = getBridge(component);
                //если он не пуст
                if (bridge != null)
                {
                    managedForm.setText("ребро " + (bridge.start.id + 1).ToString() + " -> " + (bridge.end.id + 1).ToString() + " - мост. Используем специальную укладку графа с мостами.");
                    //запускаем особую укладку графа с мостами
                    specialFloatLaying(component, bridge);
                }
                else
                {
                    managedForm.setText("Мост не найден. Запускаем обычную укладку.");
                    //иначе запускаем обычную укладку графа
                    standartFloatLaying(component);
                }
            }
            List<int> cycle = getCycle(component);
        }

        //укладываем одно дерево
        private void FloatLayingOfTree(Component component, float x, float y)
        {
            //отмечаем все вершины дерева как не пройденные
            foreach (int num in component.vertices)
                markers[num] = false;
            //начальную вершину помечаем, как пройденную
            markers[component.vertices[0]] = true;
            //запускаем рисование вершин с начальной вершины
            drawVertexOfTree(component.vertices[0], ref x, y);
        }


        private void drawNextVertexOfTree(int id, ref float x, float y, ref float x_left, ref bool isFirstTime)
        {
            //если уж посещали вершину, пропускаем её
            if (markers[id] != false)
                return;
            else
            {
                //иначе маркируем
                markers[id] = true;
                x += Params.diameter * 2;
                //и запускаем её oтрисовку
                drawVertexOfTree(id, ref x, y);
                if (isFirstTime)
                {
                    x_left = x;
                    isFirstTime = false;
                }
            }
        }

        //отрисовка одной вершины дерева
        private void drawVertexOfTree(int start, ref float x, float y)
        {
            Vertex ver = vertices[start];
            float x_left = x;
            bool isFirstTime = true;
            x += Params.diameter * 4;
            //бежим по всем входящим ребрам
            foreach (KeyValuePair<Vertex, Edge> pair in ver.entry_edges)
                drawNextVertexOfTree(pair.Key.id, ref x, y + Params.diameter * 4, ref x_left, ref isFirstTime);
            //бежим по всем исходящим ребрам ребрам
            foreach (KeyValuePair<Vertex, Edge> pair in ver.exit_edges)
                drawNextVertexOfTree(pair.Key.id, ref x, y + Params.diameter * 4, ref x_left, ref isFirstTime);
            x = (x + x_left) / 2;
            //устанавливаем вершине необходимые координаты
            ver.setCoordinates(x, y);
        }

        private Edge getBridge(Component component)
        {
            int n = component.VerCount;
            int[] TimeIn = new int[n];
            int[] LowTime = new int[n];
            bool[] Used = new bool[n];
            int timer = 0;
            return dfs(component.vertices, vertices[component.vertices[0]], ref TimeIn, ref LowTime, ref Used, ref timer, -1);
        }

        private Edge dfs(
            List<int> Vertices, 
            Vertex ver, 
            ref int[] TimeIn, 
            ref int[] LowTime, 
            ref bool[] Used, 
            ref int timer,
            int parent)
        {
            int v = ver.id;
            Used[v] = true;
            TimeIn[v] = LowTime[v] = timer++;
            foreach (KeyValuePair<Vertex, Edge> pair in ver.entry_edges)
            {
                //вершина в которую пришли
                int to = pair.Value.start.id;
                //если пытаемся пойти обратно выходим
                if (to == parent)
                    continue;
                //если уже посещали эту вершину
                if (Used[to])
                    LowTime[v] = Math.Min(LowTime[v], TimeIn[to]);
                else
                {
                    //если не посещали, запускаемся из этой вершины
                    dfs(Vertices, vertices[to], ref TimeIn, ref LowTime, ref Used, ref timer, v);
                    LowTime[v] = Math.Min(LowTime[v], LowTime[to]);
                    if (LowTime[to] > TimeIn[v])
                        return pair.Value;
                }
            }
            foreach (KeyValuePair<Vertex, Edge> pair in ver.exit_edges)
            {
                //вершина в которую пришли
                int to = pair.Value.end.id;
                //если пытаемся пойти обратно выходим
                if (to == parent)
                    continue;
                //если уже посещали эту вершину
                if (Used[to])
                    LowTime[v] = Math.Min(LowTime[v], TimeIn[to]);
                else
                {
                    //если не посещали, запускаемся из этой вершины
                    dfs(Vertices, vertices[to], ref TimeIn, ref LowTime, ref Used, ref timer, v);
                    LowTime[v] = Math.Min(LowTime[v], LowTime[to]);
                    if (LowTime[to] > TimeIn[v])
                        return pair.Value;
                }
            }
            return null;            
        }

        //укладка графа с мостом
        private void specialFloatLaying(Component component, Edge bridge)
        {
        }

        private void standartFloatLaying(Component component)
        {
        }

        List<int> getCycle(Component component)
        {
            return component.vertices;
        }

    }
}
