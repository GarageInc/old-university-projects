﻿namespace course_work_zd
{
    partial class FFloatLaying
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (bt_exit.Enabled)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_info = new System.Windows.Forms.TextBox();
            this.bt_start = new System.Windows.Forms.Button();
            this.bt_continue = new System.Windows.Forms.Button();
            this.bt_exit = new System.Windows.Forms.Button();
            this.bt_pause = new System.Windows.Forms.Button();
            this.lb_speed = new System.Windows.Forms.Label();
            this.bt_faster = new System.Windows.Forms.Button();
            this.bt_slowlier = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_info
            // 
            this.tb_info.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_info.BackColor = System.Drawing.Color.White;
            this.tb_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_info.Location = new System.Drawing.Point(12, 12);
            this.tb_info.Multiline = true;
            this.tb_info.Name = "tb_info";
            this.tb_info.ReadOnly = true;
            this.tb_info.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_info.Size = new System.Drawing.Size(306, 291);
            this.tb_info.TabIndex = 1;
            this.tb_info.Text = "Алгоритм не запущен.";
            // 
            // bt_start
            // 
            this.bt_start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bt_start.Location = new System.Drawing.Point(12, 309);
            this.bt_start.Name = "bt_start";
            this.bt_start.Size = new System.Drawing.Size(75, 23);
            this.bt_start.TabIndex = 2;
            this.bt_start.Text = "Запустить";
            this.bt_start.UseVisualStyleBackColor = true;
            this.bt_start.Click += new System.EventHandler(this.bt_start_Click);
            // 
            // bt_continue
            // 
            this.bt_continue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bt_continue.Location = new System.Drawing.Point(213, 309);
            this.bt_continue.Name = "bt_continue";
            this.bt_continue.Size = new System.Drawing.Size(82, 23);
            this.bt_continue.TabIndex = 4;
            this.bt_continue.Text = "Продолжить";
            this.bt_continue.UseVisualStyleBackColor = true;
            this.bt_continue.Click += new System.EventHandler(this.bt_continue_Click);
            // 
            // bt_exit
            // 
            this.bt_exit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bt_exit.Location = new System.Drawing.Point(327, 309);
            this.bt_exit.Name = "bt_exit";
            this.bt_exit.Size = new System.Drawing.Size(75, 23);
            this.bt_exit.TabIndex = 5;
            this.bt_exit.Text = "Выход";
            this.bt_exit.UseVisualStyleBackColor = true;
            this.bt_exit.Click += new System.EventHandler(this.bt_exit_Click);
            // 
            // bt_pause
            // 
            this.bt_pause.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bt_pause.Location = new System.Drawing.Point(113, 309);
            this.bt_pause.Name = "bt_pause";
            this.bt_pause.Size = new System.Drawing.Size(75, 23);
            this.bt_pause.TabIndex = 6;
            this.bt_pause.Text = "Остановить";
            this.bt_pause.UseVisualStyleBackColor = true;
            this.bt_pause.Click += new System.EventHandler(this.bt_pause_Click);
            // 
            // lb_speed
            // 
            this.lb_speed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_speed.AutoSize = true;
            this.lb_speed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_speed.Location = new System.Drawing.Point(324, 28);
            this.lb_speed.Name = "lb_speed";
            this.lb_speed.Size = new System.Drawing.Size(81, 16);
            this.lb_speed.TabIndex = 7;
            this.lb_speed.Text = "Скорость:";
            // 
            // bt_faster
            // 
            this.bt_faster.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_faster.Location = new System.Drawing.Point(327, 60);
            this.bt_faster.Name = "bt_faster";
            this.bt_faster.Size = new System.Drawing.Size(75, 23);
            this.bt_faster.TabIndex = 8;
            this.bt_faster.Text = "Быстрее";
            this.bt_faster.UseVisualStyleBackColor = true;
            this.bt_faster.Click += new System.EventHandler(this.bt_faster_Click);
            // 
            // bt_slowlier
            // 
            this.bt_slowlier.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_slowlier.Location = new System.Drawing.Point(327, 89);
            this.bt_slowlier.Name = "bt_slowlier";
            this.bt_slowlier.Size = new System.Drawing.Size(75, 23);
            this.bt_slowlier.TabIndex = 9;
            this.bt_slowlier.Text = "Медленнее";
            this.bt_slowlier.UseVisualStyleBackColor = true;
            this.bt_slowlier.Click += new System.EventHandler(this.bt_slowlier_Click);
            // 
            // FFloatLaying
            // 
            this.AcceptButton = this.bt_start;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 344);
            this.Controls.Add(this.bt_slowlier);
            this.Controls.Add(this.bt_faster);
            this.Controls.Add(this.lb_speed);
            this.Controls.Add(this.bt_pause);
            this.Controls.Add(this.bt_exit);
            this.Controls.Add(this.bt_continue);
            this.Controls.Add(this.bt_start);
            this.Controls.Add(this.tb_info);
            this.MinimumSize = new System.Drawing.Size(428, 202);
            this.Name = "FFloatLaying";
            this.ShowIcon = false;
            this.Text = "Плоская укладка";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_info;
        private System.Windows.Forms.Button bt_start;
        private System.Windows.Forms.Button bt_continue;
        private System.Windows.Forms.Button bt_exit;
        private System.Windows.Forms.Button bt_pause;
        private System.Windows.Forms.Label lb_speed;
        private System.Windows.Forms.Button bt_faster;
        private System.Windows.Forms.Button bt_slowlier;
    }
}