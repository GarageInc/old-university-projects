﻿//GraphProg.cs
//Zubarevich D.A. 2.04.11
//There is entry point for this application

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    static class GraphProg
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FGraph());
        }
    }
}
