﻿//FManual.cs
//Zubarevich D.A. 7.04.11
//Manual info for this application

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FManual : Form
    {
        public FManual()
        {
            InitializeComponent();
            tb_info.ScrollBars = ScrollBars.Vertical;
        }

        private void bt_ok_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
