﻿namespace course_work_zd
{
    partial class FAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FAbout));
            this.bt_ok = new System.Windows.Forms.Button();
            this.lb_head = new System.Windows.Forms.Label();
            this.tc_history = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lb_history_1_0 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lb_history_1_1 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lb_history_1_2 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lb_history_1_3 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lb_history_2_0 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.lb_history_2_1 = new System.Windows.Forms.Label();
            this.lb_history = new System.Windows.Forms.Label();
            this.tc_history.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_ok
            // 
            this.bt_ok.Location = new System.Drawing.Point(215, 370);
            this.bt_ok.Name = "bt_ok";
            this.bt_ok.Size = new System.Drawing.Size(75, 23);
            this.bt_ok.TabIndex = 1;
            this.bt_ok.Text = "Ok";
            this.bt_ok.UseVisualStyleBackColor = true;
            this.bt_ok.Click += new System.EventHandler(this.bt_ok_Click);
            // 
            // lb_head
            // 
            this.lb_head.AutoSize = true;
            this.lb_head.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_head.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lb_head.Location = new System.Drawing.Point(12, 9);
            this.lb_head.Name = "lb_head";
            this.lb_head.Size = new System.Drawing.Size(278, 72);
            this.lb_head.TabIndex = 2;
            this.lb_head.Text = "Graph Bilder v 2.1\r\n\r\n    Автор: Зубаревич Дмитрий\r\n                           Ап" +
                "рель-Май 2011";
            // 
            // tc_history
            // 
            this.tc_history.Controls.Add(this.tabPage1);
            this.tc_history.Controls.Add(this.tabPage2);
            this.tc_history.Controls.Add(this.tabPage3);
            this.tc_history.Controls.Add(this.tabPage4);
            this.tc_history.Controls.Add(this.tabPage5);
            this.tc_history.Controls.Add(this.tabPage6);
            this.tc_history.Location = new System.Drawing.Point(-2, 111);
            this.tc_history.Name = "tc_history";
            this.tc_history.SelectedIndex = 0;
            this.tc_history.Size = new System.Drawing.Size(310, 253);
            this.tc_history.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lb_history_1_0);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(302, 227);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "v 1.0";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lb_history_1_0
            // 
            this.lb_history_1_0.AutoSize = true;
            this.lb_history_1_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_1_0.Location = new System.Drawing.Point(24, 27);
            this.lb_history_1_0.Name = "lb_history_1_0";
            this.lb_history_1_0.Size = new System.Drawing.Size(248, 128);
            this.lb_history_1_0.TabIndex = 0;
            this.lb_history_1_0.Text = resources.GetString("lb_history_1_0.Text");
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lb_history_1_1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(302, 227);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "v 1.1";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lb_history_1_1
            // 
            this.lb_history_1_1.AutoSize = true;
            this.lb_history_1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_1_1.Location = new System.Drawing.Point(6, 21);
            this.lb_history_1_1.Name = "lb_history_1_1";
            this.lb_history_1_1.Size = new System.Drawing.Size(290, 128);
            this.lb_history_1_1.TabIndex = 0;
            this.lb_history_1_1.Text = resources.GetString("lb_history_1_1.Text");
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lb_history_1_2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(302, 227);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "v 1.2";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lb_history_1_2
            // 
            this.lb_history_1_2.AutoSize = true;
            this.lb_history_1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_1_2.Location = new System.Drawing.Point(14, 22);
            this.lb_history_1_2.Name = "lb_history_1_2";
            this.lb_history_1_2.Size = new System.Drawing.Size(261, 128);
            this.lb_history_1_2.TabIndex = 0;
            this.lb_history_1_2.Text = resources.GetString("lb_history_1_2.Text");
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lb_history_1_3);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(302, 227);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "v 1.3";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // lb_history_1_3
            // 
            this.lb_history_1_3.AutoSize = true;
            this.lb_history_1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_1_3.Location = new System.Drawing.Point(26, 23);
            this.lb_history_1_3.Name = "lb_history_1_3";
            this.lb_history_1_3.Size = new System.Drawing.Size(241, 80);
            this.lb_history_1_3.TabIndex = 0;
            this.lb_history_1_3.Text = " 1) Улучшение отображения имен \r\nвершин (всплывающие подсказки);\r\n 2) Добавление " +
                "иконки приложения;\r\n 3) Исправление отображения\r\nсообщений об ошибках.";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.lb_history_2_0);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(302, 227);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "v 2.0";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // lb_history_2_0
            // 
            this.lb_history_2_0.AutoSize = true;
            this.lb_history_2_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_2_0.Location = new System.Drawing.Point(14, 15);
            this.lb_history_2_0.Name = "lb_history_2_0";
            this.lb_history_2_0.Size = new System.Drawing.Size(281, 208);
            this.lb_history_2_0.TabIndex = 0;
            this.lb_history_2_0.Text = resources.GetString("lb_history_2_0.Text");
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.lb_history_2_1);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(302, 227);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "v 2.1";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // lb_history_2_1
            // 
            this.lb_history_2_1.AutoSize = true;
            this.lb_history_2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history_2_1.Location = new System.Drawing.Point(26, 23);
            this.lb_history_2_1.Name = "lb_history_2_1";
            this.lb_history_2_1.Size = new System.Drawing.Size(255, 96);
            this.lb_history_2_1.TabIndex = 0;
            this.lb_history_2_1.Text = "1) Исправление проблемы с \r\nфокусом ввода;\r\n2) Добавление особой обработки \r\nпоис" +
                "ка путей из вершины в неё саму;\r\n3) Исправление перерисовки вершин \r\nпри движени" +
                "и.";
            // 
            // lb_history
            // 
            this.lb_history.AutoSize = true;
            this.lb_history.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_history.Location = new System.Drawing.Point(16, 92);
            this.lb_history.Name = "lb_history";
            this.lb_history.Size = new System.Drawing.Size(160, 16);
            this.lb_history.TabIndex = 4;
            this.lb_history.Text = "История изменений:";
            // 
            // FAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(305, 402);
            this.Controls.Add(this.lb_history);
            this.Controls.Add(this.tc_history);
            this.Controls.Add(this.lb_head);
            this.Controls.Add(this.bt_ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FAbout";
            this.Text = "О программе";
            this.tc_history.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_ok;
        private System.Windows.Forms.Label lb_head;
        private System.Windows.Forms.TabControl tc_history;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lb_history;
        private System.Windows.Forms.Label lb_history_1_0;
        private System.Windows.Forms.Label lb_history_1_1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label lb_history_1_2;
        private System.Windows.Forms.Label lb_history_1_3;
        private System.Windows.Forms.Label lb_history_2_0;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label lb_history_2_1;
    }
}