﻿//exchanger.cs
//Zubarevich D.A. 5.04.11
//last update 11.05.11
//This class is used for exchange by data between two forms

namespace course_work_zd
{
    public static class exchanger
    {
        public static int weight;
        public static Edge edge;
        public static Vertex ver;
        public static string name;
        public static int dx = 0, dy = 0;
    }
}
