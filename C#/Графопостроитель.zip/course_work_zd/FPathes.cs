﻿//FPathes.cs
//Zubarevich D.A. 7.04.11
//last update 13.05.11
//Search of pathes between two vertices

using System;
using System.Windows.Forms;
using System.Collections.Generic;

namespace course_work_zd
{
    public partial class FPathes : Form
    {
        public FPathes(Graph graph)
        {
            InitializeComponent();
            this.graph = graph;
        }
        //ссылка на граф
        Graph graph;
        //идентификаторы и ссылки на начальную и конечную вершины
        int start, end; Vertex startVer, endVer;

        //добавление вершины к пути
        private void AddToPath(ref string path, int number, int weight)
        {
            int index = path.IndexOf(";");
            string temp = path.Substring(0, index);
            string sum = path.Substring(index + 1);
            //меняем вес
            weight += Convert.ToInt32(sum);
            //наращиваем путь
            path = temp + " -> " + number.ToString() + "; " + weight.ToString();
        }

        //поиск путей в графе
        private List<string> dfs(Vertex current, string path, int weight)
        {
            //создаем новый список путей
            List<string> pathes = new List<string>();
            //если в пути уже встречался эта вершина возвращаем пустой список
            if (path.IndexOf(" " + (current.id + 1).ToString() + " ") != -1)
                return pathes;
            else
                //в противном случае
                //если путь ещё не был начат, начинаем
                if (path == "")
                    path = " " + (current.id + 1).ToString() + "; " + weight.ToString();
                else
                    AddToPath(ref path, current.id + 1, weight);
            //если дошли до последней вершины завершаем построение пути
            if (current.id == end)
            {
                pathes.Add(path);
                return pathes;
            }
            //просматриваем все вершины, в которые идут ребра из данной
            foreach (KeyValuePair<Vertex, Edge> pair in current.exit_edges)
            {
                //для каждой вершины получаем список путей
                List<string> result = dfs(pair.Key, path, pair.Value.weight);
                //если есть хоть один путь до конечной вершины
                if (result.Count != 0)
                    //добавляем этот спмсок к общему списку
                    pathes.AddRange(result);
            }
            return pathes; 
        }

        private void bt_ok_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bt_getPathes_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(tb_start.Text, out start) ||
                !int.TryParse(tb_end.Text, out end) ||
                !FGraph.checkChangeName(--start, out startVer) ||
                !FGraph.checkChangeName(--end, out endVer))
            {
                tb_result.Text = "Неправильный идентификатор вершины.";
            }
            else
            {
                tb_result.Text = null;
                List<string> list = new List<string>();
                //если конечная вершина совпадает с начальной
                if (end == start)
                {
                    //добавляем тривиальный путь
                    list.Add(" " + (start + 1).ToString() + "; 0");
                    //просматриваем все ребра исходящие из этой вершины
                    foreach (KeyValuePair<Vertex, Edge> pair in startVer.exit_edges)
                    {
                        Vertex ver = pair.Key;
                        //вычисляем пути от инцидентных вершин
                        List<string> currentList = dfs(ver, "", pair.Value.weight);
                        //приписываем к найденым путям начальную вершину
                        int n = currentList.Count;
                        for (int i = 0; i < n; i++)
                            currentList[i] = " " + (start + 1).ToString() + " ->" + currentList[i];
                        //добавляем к списку
                        list.AddRange(currentList);
                    }
                }
                else
                    list = dfs(startVer, "", 0);
                if(list.Count == 0)
                    tb_result.Text += "Ни один путь не был найден.";
                int j = 1;
                foreach (string str in list)
                {
                    tb_result.Text += j.ToString() + ")" + str + Environment.NewLine;
                    j++;
                }
            }
        }
    }
}
