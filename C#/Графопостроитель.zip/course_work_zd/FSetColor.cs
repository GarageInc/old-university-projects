﻿//FSetColor.cs
//Zubarevich D.A. 5.04.11
//last update 09.05.11
//There is a form for set of edges` color

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FSetColor : Form
    {
        public FSetColor()
        {
            InitializeComponent();
        }

        private void bt_change_Click(object sender, EventArgs e)
        {
            int start, end;
            if (!int.TryParse(tb_initial.Text, out start) ||
                !int.TryParse(tb_final.Text, out end) ||
                !FGraph.checkChangeWeight(start - 1, end - 1, out exchanger.edge))
            {
                DialogResult = DialogResult.Cancel;
                MessageBox.Show("Ошибка ввода!");
            }
            else
            {
                DialogResult = DialogResult.OK;
            }
        }

        private void tb_initial_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                bt_change_Click(null, null);
        }
    }
}
