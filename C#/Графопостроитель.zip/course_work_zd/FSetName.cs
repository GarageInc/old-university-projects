﻿//FSetName.cs
//Zubarevich D.A. 7.04.11
//last update 09.05.11
//Window for setting of name a vertex

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FSetName : Form
    {
        public FSetName()
        {
            InitializeComponent();
        }

        public FSetName(Vertex ver)
        {
            InitializeComponent();
            tb_id.Text = (ver.id + 1).ToString();
            tb_id.ReadOnly = true;
            tb_name.Text = (string)ver.data;
        }

        private void bt_ok_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(tb_id.Text, out id) ||
                !FGraph.checkChangeName(--id, out exchanger.ver))
            {
                MessageBox.Show("Ошибка ввода!");
                DialogResult = DialogResult.Cancel;
            }
            else
            {
                exchanger.name = tb_name.Text;
                DialogResult = DialogResult.OK;
            }
        }

        private void bt_cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tb_id_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                bt_ok_Click(null, null);
        }


    }
}

