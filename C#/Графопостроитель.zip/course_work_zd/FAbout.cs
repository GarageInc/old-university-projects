﻿//FAbout.cs
//Zubarevich D.A. 7.04.11
//last update 09.05.11
//Info about program

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FAbout : Form
    {
        public FAbout()
        {
            InitializeComponent();
        }

        private void bt_ok_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
