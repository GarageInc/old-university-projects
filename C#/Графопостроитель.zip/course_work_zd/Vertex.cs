﻿//Vertex.cs
//Zubarevich D.A. 2.04.11
//last update 15.05.11
//Work with graph`s vertices is represented by this class 

using System.Collections.Generic;
using System.Drawing;

namespace course_work_zd
{
    public class Vertex
    {
        //уникальный идентификатор
        public int id {get; set;}
        //данные
        public object data { get; set; }
        //координаты вершины
        public float x {get; set;}
        public float y { get; set; } 
        //хэштаблица входящих ребер
        public Dictionary<Vertex, Edge> entry_edges { get; set; }
        //хэштаблица исходяших ребер
        public Dictionary<Vertex, Edge> exit_edges { get; set; }
        //выделение
        bool isSelected = false;
        //цвет фона вершины
        public Color color { get; set; }
        //свойство для выделения
        public bool IsSelected {
            get {
                return isSelected;
            }
            set {
                isSelected = value;
            }
        }
        //Двигали ли уже вершину
        public bool isAlreadyMove { get; set; }

        //создание вкршины
        public Vertex(int id)
        {
            this.id = id;
            data = null;
            entry_edges = new Dictionary<Vertex, Edge>();
            exit_edges = new Dictionary<Vertex, Edge>();
            x = y = 0F;
            this.data = "";
            color = Params.brushFone;
        }

        //создание вершины с данными
        public Vertex(int id, object data)
        {
            this.id = id;
            this.data = data;
            entry_edges = new Dictionary<Vertex, Edge>();
            exit_edges = new Dictionary<Vertex, Edge>();
            x = y = 0F;
            color = Params.brushFone;
        }

        //создание вершины с координатами
        public Vertex(int id, float x, float y)
        {
            this.id = id;
            this.data = "";
            this.x = x;
            this.y = y;
            entry_edges = new Dictionary<Vertex, Edge>();
            exit_edges = new Dictionary<Vertex, Edge>();
            color = Params.brushFone;
        }

        //создание вершины с данными и координатами
        public Vertex(int id, object data, float x, float y)
        {
            this.id = id;
            this.data = data;
            this.x = x;
            this.y = y;
            entry_edges = new Dictionary<Vertex, Edge>();
            exit_edges = new Dictionary<Vertex, Edge>();
            color = Params.brushFone;
        }

        //передвижение вершины
        public void move(float dx, float dy)
        {
            //Проверяем не двигали ли уже вершину
            if (isAlreadyMove)
                return;
            isAlreadyMove = true;
            x += dx;
            y += dy;
        }

        //отрисовка вершины
        public void draw(Graphics g, int mouseX, int mouseY)
        {
            x += exchanger.dx;
            y += exchanger.dy;
            Pen pen = isSelected ? Params.data_select_pen : Params.data_pen;
            SolidBrush brush = new SolidBrush(color);
            g.FillEllipse(brush, x, y, Params.diameter, Params.diameter);
            g.DrawEllipse(pen, x, y, Params.diameter, Params.diameter);
            //отображение номера вершины
            g.DrawString((id + 1).ToString(), Params.font, Params.brush, x, y + (Params.diameter - Params.font.Size) / 4);
            //отображение полной строки если мышь наведена на на данную  вершину
            if (isContain(mouseX, mouseY) & (string)data != "")
                drawFullName(g);
        }

        //отображение дополнительной информации
        private void drawFullName(Graphics g)
        {
            string name = data.ToString();
            SizeF size = g.MeasureString(name, Params.font);
            g.FillRectangle(Params.TipFoneBrush, x, y - Params.ver_height, size.Width + 2, size.Height + 2);
            g.DrawRectangle(Params.TipPen, x, y - Params.ver_height, size.Width + 2, size.Height + 2);
            g.DrawString(name, Params.font, Params.TipBrush, x, y - Params.ver_height);
        }

        //принадлежность точки вершине
        public bool isContain(int X, int Y)
        {
            float dx = X - x - Params.radius;
            float dy = Y - y - Params.radius;
            if (dx * dx + dy * dy <= Params.radius * Params.radius)                
                return true;
            return false;
        }

        //делегат для передачи ф-ии удаления ребра из графа
        public delegate void del_edge(int id);

        //удаление входящих и исходящих ребер
        public void clean_edges(del_edge de)
        {
            //списки ребер подлежащих удалению
            List<Edge> remove_entry = new List<Edge>();
            List<Edge> remove_exit = new List<Edge>();
            //определяем ребра
            foreach (Edge edge in exit_edges.Values)
                remove_entry.Add(edge);
            foreach (Edge edge in entry_edges.Values)
                remove_exit.Add(edge);
            //удаляем ребра
            while (remove_entry.Count > 0)
            {
                //удаляем ребро из графа
                de(remove_entry[0].id);
                //чистим ссылки на ребро
                remove_entry[0].end.entry_edges.Remove(this);
                remove_entry.RemoveAt(0);
            }
            while (remove_exit.Count > 0)
            {
                //удаляем ребро из графа
                de(remove_exit[0].id);
                //чистим ссылки на ребро
                remove_exit[0].start.exit_edges.Remove(this);
                remove_exit.RemoveAt(0);
            }
        }

        //
        public void setCoordinates(float x, float y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
