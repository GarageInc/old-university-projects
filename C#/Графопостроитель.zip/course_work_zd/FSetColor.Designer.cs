﻿namespace course_work_zd
{
    partial class FSetColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_init = new System.Windows.Forms.Label();
            this.lb_final = new System.Windows.Forms.Label();
            this.tb_initial = new System.Windows.Forms.TextBox();
            this.tb_final = new System.Windows.Forms.TextBox();
            this.bt_change = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_init
            // 
            this.lb_init.AutoSize = true;
            this.lb_init.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_init.Location = new System.Drawing.Point(21, 19);
            this.lb_init.Name = "lb_init";
            this.lb_init.Size = new System.Drawing.Size(189, 16);
            this.lb_init.TabIndex = 0;
            this.lb_init.Text = "Номер начальной вершины:";
            // 
            // lb_final
            // 
            this.lb_final.AutoSize = true;
            this.lb_final.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_final.Location = new System.Drawing.Point(21, 50);
            this.lb_final.Name = "lb_final";
            this.lb_final.Size = new System.Drawing.Size(181, 16);
            this.lb_final.TabIndex = 1;
            this.lb_final.Text = "Номер конечной вершины:";
            // 
            // tb_initial
            // 
            this.tb_initial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_initial.Location = new System.Drawing.Point(219, 16);
            this.tb_initial.Name = "tb_initial";
            this.tb_initial.Size = new System.Drawing.Size(63, 22);
            this.tb_initial.TabIndex = 2;
            this.tb_initial.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_initial_KeyDown);
            // 
            // tb_final
            // 
            this.tb_final.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_final.Location = new System.Drawing.Point(219, 50);
            this.tb_final.Name = "tb_final";
            this.tb_final.Size = new System.Drawing.Size(63, 22);
            this.tb_final.TabIndex = 3;
            this.tb_final.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_initial_KeyDown);
            // 
            // bt_change
            // 
            this.bt_change.Location = new System.Drawing.Point(185, 91);
            this.bt_change.Name = "bt_change";
            this.bt_change.Size = new System.Drawing.Size(97, 23);
            this.bt_change.TabIndex = 4;
            this.bt_change.Text = "Изменить цвет";
            this.bt_change.UseVisualStyleBackColor = true;
            this.bt_change.Click += new System.EventHandler(this.bt_change_Click);
            // 
            // FSetColor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 126);
            this.Controls.Add(this.bt_change);
            this.Controls.Add(this.tb_final);
            this.Controls.Add(this.tb_initial);
            this.Controls.Add(this.lb_final);
            this.Controls.Add(this.lb_init);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FSetColor";
            this.ShowIcon = false;
            this.Text = "Изменение цвета ребра";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_init;
        private System.Windows.Forms.Label lb_final;
        private System.Windows.Forms.TextBox tb_initial;
        private System.Windows.Forms.TextBox tb_final;
        private System.Windows.Forms.Button bt_change;
    }
}