﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace course_work_zd
{
    public partial class FFloatLaying : Form
    {
         //делегат для передачи ф-ии установки возможности изменения графа
        public delegate void Changeable(bool canChange);

        public FFloatLaying(FGraph form, Graph graph, Changeable changeable, Thread FloatLayingThread)
        {
            InitializeComponent();
            tb_info.Select(0, 0);
            this.form = form;
            this.graph = graph;
            this.changeable = changeable;
            this.FloatLayingThread = FloatLayingThread;
            bt_continue.Enabled = false;
            bt_pause.Enabled = false;
        }

        //установка возможности изменения графа
        private Changeable changeable;
        //форма с графом
        private FGraph form;
        //граф
        private Graph graph;
        //поток для плоской укладки
        private Thread FloatLayingThread;

        //делегат для вывода текста
        delegate void SetText(string message);

        //вывод текста
        public void setText(string message)
        {
            //если вызов из второго потока
            if (tb_info.InvokeRequired)
            {
                graph.sleep();
                //запускаемся из основного потока
                this.Invoke(new SetText(setText), new object[] { message });
            }
            else
                //иначе просто выполняем метод
                tb_info.AppendText("  " + message + Environment.NewLine + Environment.NewLine);
        }

        //запуск алгоритма
        private void bt_start_Click(object sender, EventArgs e)
        {
            bt_start.Enabled = false;
            bt_exit.Enabled = false;
            bt_continue.Enabled = false;
            bt_pause.Enabled = true;
            tb_info.Text = null;
            setText("Алгоритм укладки запущен.");
            FloatLayingThread.Start();
        }
        //остановка алгоритма
        private void bt_pause_Click(object sender, EventArgs e)
        {
            FloatLayingThread.Suspend();
            bt_continue.Enabled = true;
            bt_pause.Enabled = false;
        }

        //продолжение алгоритма
        private void bt_continue_Click(object sender, EventArgs e)
        {
            FloatLayingThread.Resume();
            bt_pause.Enabled = true;
            bt_continue.Enabled = false;
        }
        //выход
        private void bt_exit_Click(object sender, EventArgs e)
        {
            if (bt_exit.Enabled)
            {
                changeable(true);
                Close();
            }
        }

        //ускорение алгоритма
        private void bt_faster_Click(object sender, EventArgs e)
        {
            if (Params.sleep != 0)
                Params.sleep -= 250;
            else
            {
                form.isNeedInvalidating = false;
                MessageBox.Show("Скорость максимальна!");
                form.isNeedInvalidating = true;
            }
        }

        //замедление алгоритма
        private void bt_slowlier_Click(object sender, EventArgs e)
        {
            Params.sleep += 250;
        }

        //сообщить об окончании алгоритма
        public void SignalAboutEnd()
        {
            bt_continue.Enabled = false;
            bt_pause.Enabled = false;
            bt_start.Enabled = false;
            bt_exit.Enabled = true;
        }
    }
}
