﻿namespace course_work_zd
{
    partial class FPathes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_start = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_start = new System.Windows.Forms.TextBox();
            this.tb_end = new System.Windows.Forms.TextBox();
            this.bt_getPathes = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_result = new System.Windows.Forms.TextBox();
            this.bt_ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb_start
            // 
            this.lb_start.AutoSize = true;
            this.lb_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_start.Location = new System.Drawing.Point(24, 23);
            this.lb_start.Name = "lb_start";
            this.lb_start.Size = new System.Drawing.Size(189, 16);
            this.lb_start.TabIndex = 0;
            this.lb_start.Text = "Номер начальной вершины:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(24, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Номер конечной вершины:";
            // 
            // tb_start
            // 
            this.tb_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_start.Location = new System.Drawing.Point(218, 23);
            this.tb_start.Name = "tb_start";
            this.tb_start.Size = new System.Drawing.Size(51, 22);
            this.tb_start.TabIndex = 2;
            // 
            // tb_end
            // 
            this.tb_end.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_end.Location = new System.Drawing.Point(218, 53);
            this.tb_end.Name = "tb_end";
            this.tb_end.Size = new System.Drawing.Size(51, 22);
            this.tb_end.TabIndex = 3;
            // 
            // bt_getPathes
            // 
            this.bt_getPathes.Location = new System.Drawing.Point(287, 37);
            this.bt_getPathes.Name = "bt_getPathes";
            this.bt_getPathes.Size = new System.Drawing.Size(75, 23);
            this.bt_getPathes.TabIndex = 4;
            this.bt_getPathes.Text = "Искать";
            this.bt_getPathes.UseVisualStyleBackColor = true;
            this.bt_getPathes.Click += new System.EventHandler(this.bt_getPathes_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(24, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Найденные пути с весом:";
            // 
            // tb_result
            // 
            this.tb_result.BackColor = System.Drawing.Color.White;
            this.tb_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tb_result.Location = new System.Drawing.Point(27, 107);
            this.tb_result.Multiline = true;
            this.tb_result.Name = "tb_result";
            this.tb_result.ReadOnly = true;
            this.tb_result.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_result.Size = new System.Drawing.Size(335, 134);
            this.tb_result.TabIndex = 6;
            // 
            // bt_ok
            // 
            this.bt_ok.Location = new System.Drawing.Point(287, 247);
            this.bt_ok.Name = "bt_ok";
            this.bt_ok.Size = new System.Drawing.Size(75, 23);
            this.bt_ok.TabIndex = 7;
            this.bt_ok.Text = "Закончить";
            this.bt_ok.UseVisualStyleBackColor = true;
            this.bt_ok.Click += new System.EventHandler(this.bt_ok_Click);
            // 
            // FPathes
            // 
            this.AcceptButton = this.bt_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 281);
            this.Controls.Add(this.bt_ok);
            this.Controls.Add(this.tb_result);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bt_getPathes);
            this.Controls.Add(this.tb_end);
            this.Controls.Add(this.tb_start);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lb_start);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FPathes";
            this.Text = "Поиск путей";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_start;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_start;
        private System.Windows.Forms.TextBox tb_end;
        private System.Windows.Forms.Button bt_getPathes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_result;
        private System.Windows.Forms.Button bt_ok;
    }
}