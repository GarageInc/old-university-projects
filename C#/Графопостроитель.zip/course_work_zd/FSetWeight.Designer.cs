﻿namespace course_work_zd
{
    partial class FSetWeight
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_weight = new System.Windows.Forms.TextBox();
            this.tb_final = new System.Windows.Forms.TextBox();
            this.tb_initial = new System.Windows.Forms.TextBox();
            this.lb_initial = new System.Windows.Forms.Label();
            this.lb_final = new System.Windows.Forms.Label();
            this.lb_weight = new System.Windows.Forms.Label();
            this.bt_cancel = new System.Windows.Forms.Button();
            this.bt_ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_weight
            // 
            this.tb_weight.Location = new System.Drawing.Point(157, 75);
            this.tb_weight.Name = "tb_weight";
            this.tb_weight.Size = new System.Drawing.Size(100, 20);
            this.tb_weight.TabIndex = 0;
            this.tb_weight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_initial_KeyDown);
            // 
            // tb_final
            // 
            this.tb_final.Location = new System.Drawing.Point(219, 47);
            this.tb_final.Name = "tb_final";
            this.tb_final.Size = new System.Drawing.Size(38, 20);
            this.tb_final.TabIndex = 1;
            this.tb_final.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_initial_KeyDown);
            // 
            // tb_initial
            // 
            this.tb_initial.Location = new System.Drawing.Point(219, 21);
            this.tb_initial.Name = "tb_initial";
            this.tb_initial.Size = new System.Drawing.Size(38, 20);
            this.tb_initial.TabIndex = 2;
            this.tb_initial.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tb_initial_KeyDown);
            // 
            // lb_initial
            // 
            this.lb_initial.AutoSize = true;
            this.lb_initial.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_initial.Location = new System.Drawing.Point(24, 21);
            this.lb_initial.Name = "lb_initial";
            this.lb_initial.Size = new System.Drawing.Size(189, 16);
            this.lb_initial.TabIndex = 3;
            this.lb_initial.Text = "Номер начальной вершины:\r\n";
            // 
            // lb_final
            // 
            this.lb_final.AutoSize = true;
            this.lb_final.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_final.Location = new System.Drawing.Point(24, 44);
            this.lb_final.Name = "lb_final";
            this.lb_final.Size = new System.Drawing.Size(181, 16);
            this.lb_final.TabIndex = 4;
            this.lb_final.Text = "Номер конечной вершины:";
            // 
            // lb_weight
            // 
            this.lb_weight.AutoSize = true;
            this.lb_weight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_weight.Location = new System.Drawing.Point(24, 75);
            this.lb_weight.Name = "lb_weight";
            this.lb_weight.Size = new System.Drawing.Size(93, 20);
            this.lb_weight.TabIndex = 5;
            this.lb_weight.Text = "Новый вес:";
            // 
            // bt_cancel
            // 
            this.bt_cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.bt_cancel.Location = new System.Drawing.Point(27, 114);
            this.bt_cancel.Name = "bt_cancel";
            this.bt_cancel.Size = new System.Drawing.Size(75, 23);
            this.bt_cancel.TabIndex = 6;
            this.bt_cancel.Text = "Отменить";
            this.bt_cancel.UseVisualStyleBackColor = true;
            this.bt_cancel.Click += new System.EventHandler(this.bt_cancel_Click);
            // 
            // bt_ok
            // 
            this.bt_ok.Location = new System.Drawing.Point(163, 114);
            this.bt_ok.Name = "bt_ok";
            this.bt_ok.Size = new System.Drawing.Size(75, 23);
            this.bt_ok.TabIndex = 7;
            this.bt_ok.Text = "Принять";
            this.bt_ok.UseVisualStyleBackColor = true;
            this.bt_ok.Click += new System.EventHandler(this.bt_ok_Click);
            // 
            // FSetWeight
            // 
            this.AcceptButton = this.bt_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.bt_cancel;
            this.ClientSize = new System.Drawing.Size(279, 155);
            this.Controls.Add(this.bt_ok);
            this.Controls.Add(this.bt_cancel);
            this.Controls.Add(this.lb_weight);
            this.Controls.Add(this.lb_final);
            this.Controls.Add(this.lb_initial);
            this.Controls.Add(this.tb_initial);
            this.Controls.Add(this.tb_final);
            this.Controls.Add(this.tb_weight);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FSetWeight";
            this.Text = "Установка веса ребра";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_weight;
        private System.Windows.Forms.TextBox tb_final;
        private System.Windows.Forms.TextBox tb_initial;
        private System.Windows.Forms.Label lb_initial;
        private System.Windows.Forms.Label lb_final;
        private System.Windows.Forms.Label lb_weight;
        private System.Windows.Forms.Button bt_cancel;
        private System.Windows.Forms.Button bt_ok;
    }
}