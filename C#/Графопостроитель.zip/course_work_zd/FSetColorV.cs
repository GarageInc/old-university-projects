﻿//FSetColorV.cs
//Zubarevich D.A. 13.04.11
//last update 09.05.11
//There is a form for set of vertices` color

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FSetColorV : Form
    {
        public FSetColorV()
        {
            InitializeComponent();
        }

        private void bt_change_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(tb_id.Text, out id) ||
                !FGraph.checkChangeName(id - 1, out exchanger.ver))
            {
                DialogResult = DialogResult.Cancel;
                MessageBox.Show("Ошибка ввода!");
            }
            else
            {
                DialogResult = DialogResult.OK;
            }
        }

        private void tb_id_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                bt_change_Click(null, null);
        }
    }
}
