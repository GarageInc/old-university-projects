﻿//FSetWeight.cs
//Zubarevich D.A. 5.04.11
//last update 09.05.11
//There is a form for set of weight of anyone edge 

using System;
using System.Windows.Forms;

namespace course_work_zd
{
    public partial class FSetWeight : Form
    {
        public FSetWeight()
        {
            InitializeComponent();
        }

        public FSetWeight(Edge edge)
        {
            InitializeComponent();
            tb_initial.Text = (edge.start.id + 1).ToString();
            tb_final.Text = (edge.end.id + 1).ToString();
            tb_final.ReadOnly = true;
            tb_initial.ReadOnly = true;
            tb_weight.Text = edge.weight.ToString();
        }

        private void bt_ok_Click(object sender, EventArgs e)
        {
            int start, end;
            if (!int.TryParse(tb_weight.Text, out exchanger.weight) ||
                !int.TryParse(tb_initial.Text, out start) ||
                !int.TryParse(tb_final.Text, out end) ||
                !FGraph.checkChangeWeight(start - 1, end - 1, out exchanger.edge))
            {
                MessageBox.Show("Ошибка ввода!");
                DialogResult = DialogResult.Cancel;
            }
            else
            {
                if (exchanger.weight < 0)
                {
                    MessageBox.Show("Вес не может быть отрицательным.");
                    DialogResult = DialogResult.Cancel;
                }
                DialogResult = DialogResult.OK;
            }
        }

        private void bt_cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tb_initial_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
                bt_ok_Click(null, null);
        }
    }
}
