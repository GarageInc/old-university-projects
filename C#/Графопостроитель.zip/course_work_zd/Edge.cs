﻿//Edge.cs
//Zubarevich D.A. 2.04.11
//last update 14.04.11
//Work with graph`s edges is represented by this class 

using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace course_work_zd
{
    public class Edge: ICloneable
    {
        //Начальная вершина
        public Vertex start { get; private set; }
        //Конечная вершина
        public Vertex end { get; private set; }
        //выделение ребра
        private bool isSelected = false;
        //свойство для выделения ребра
        public bool IsSelected {
            get {
                return isSelected;
            }
            set {
                isSelected = value;
            }
        }
        //вес ребра
        public int weight { get; set; }
        //цвет ребра
        public Color color { get; set; }
        //номер ребра
        public int id { get; set; }
        //создать ребро между двумя вершинами
        public Edge(int id, Vertex start, Vertex end)
        {
            this.id = id;
            this.start = start;
            this.end = end;
            color = Color.DarkRed;
            weight = 0;
        }
        //создать ребро м/у двумя вершинами с заданным весом
        public Edge(int id, Vertex start, Vertex end, int weight)
        {
            this.id = id;
            this.start = start;
            this.end = end;
            this.weight = weight;
            color = Color.DarkRed;
        }

        //вычисление косинуса и синуса
        private static void CosAndSin(float x1, float y1, float x2, float y2, out float cos, out float sin)
        {
            float dx = x2 - x1;
            float dy = y2 - y1;
            float dist = (float)Math.Sqrt(dx * dx + dy * dy);
            cos = dx / dist;
            sin = dy / dist; 
        }

        //определение координат начала и конца дуг
        private void defineCoordinate(out float x1, out float y1, out float x2, out float y2)
        {
            float cos, sin;
            CosAndSin(start.x, start.y, end.x, end.y, out cos, out sin);
            x1 = start.x + Params.radius + Params.radius * cos;
            y1 = start.y + Params.radius + Params.radius * sin;
            x2 = end.x + Params.radius - Params.radius * cos;
            y2 = end.y + Params.radius - Params.radius * sin;
        }

        //взятие графического изображения ребра
        private GraphicsPath getPath(out PointF weight)
        {
            //определяем координаты начала и конца дуг
            float x1, x2, y1, y2;
            defineCoordinate(out x1, out y1, out x2, out y2);
            GraphicsPath path = new GraphicsPath();
            Matrix change = new Matrix();
            //добавляем сдвиг
            change.Translate(x1, y1);
            //добавляем поворот
            change.Rotate((float)(180 / Math.PI * Math.Atan2(y2 - y1, x2 - x1)));
            
            float dist = (float)Math.Sqrt((x2 - x1) * (x2 - x1)
                + (y2 - y1) * (y2 - y1));
            PointF[] points = {
                                 new PointF(0, 0), 
                                 new PointF(dist / 2, Params.dif),
                                 new PointF(dist, 0)
                             };
            path.AddCurve(points);
            path.Transform(change);
            weight = new PointF(dist / 4 * 3, Params.dif);
            PointF[] temp = { weight };
            change.TransformPoints(temp);
            weight = temp[0];
            return path;
        }

        //передвижение ребра
        public void move(float dx, float dy)
        {
            if (!start.IsSelected)
                start.move(dx, dy);
            if (!end.IsSelected)
                end.move(dx, dy);
        }

        //прорисовка ребра
        public void draw(Graphics g)
        {
            Pen pen; PointF weight;
            if (isSelected)
                pen = Params.edge_pen_select_arrow;
            else
            {
                pen = Params.edge_pen_arrow;
                pen.Color = color;
            }
            g.DrawPath(pen, getPath(out weight));
            g.DrawString(this.weight.ToString(), Params.font_edge, new SolidBrush(pen.Color), weight);
        }

        //копирование ребра
        public object Clone()
        {
            return new Edge(id, start, end);
        }

        //избавление от ссылок на данное ребро при удалении ребра 
        public void clean_vertices()
        {
            end.entry_edges.Remove(start);
            start.exit_edges.Remove(end);
        }

        //проверка на принадлежность точки ребру
        public bool isContain(int X, int Y)
        {
            PointF temp;
            return getPath(out temp).IsOutlineVisible(X, Y, Params.edge_pen_select);
        }
    }
}
