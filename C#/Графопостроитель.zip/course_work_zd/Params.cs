﻿//Params.cs
//Zubarevich D.A. 2.04.11
//last update 23.04.11
//It is the class which contains some parameters
//for visualization of graph 

using System.Drawing;
using System.Drawing.Drawing2D;

namespace course_work_zd
{
    //Описание различных констант для настройки визуализации графа
    static class Params
    {        
        //задержка 
        public static int sleep = 2000;
        //смещение картинки
        public static int d = 40;
        //кисть для фона подсказки
        public static SolidBrush TipFoneBrush = (SolidBrush)Brushes.White;
        //кисть для подсказок
        public static SolidBrush TipBrush = (SolidBrush)Brushes.Black;
        //крандаш для подсказок
        public static Pen TipPen = Pens.Black;
        //радиус вершины
        public static float radius = 13;
        //диаметр вершины
        public static float diameter = 26;
        //ширина вершины
        public static float ver_width = 120;
        //ширина линии 
        public static float width = 2;
        //ширина выделенной линии
        public static float select_width = 3;
        //ширина стрелки на концах дуг
        private static float ar_width = 3;
        //длина стрелки на концах дуг
        private static float ar_length = 4;
        //размер шрифта
        private static float serif_size = 12.0F;
        //размер шрифта для веса
        private static float serif_size_weight = 9.0F;
        //высота вершины
        public static float ver_height = 20;
        //настройка шрифта для отображения имени вершины
        public static Font font = new Font(FontFamily.GenericSansSerif,
                                             serif_size,
                                             FontStyle.Bold);
        //настройка шрифта для отображения веса дуги
        public static Font font_edge = new Font(FontFamily.GenericSansSerif,
                                             serif_size_weight,
                                             FontStyle.Bold);
        //параметр для натройки изгиба дуги
        public static float dif = 2.5F;
        //Крандаш для данных вершины
        public static Pen data_pen = (Pen)Pens.Black.Clone();
        //Крандаш для данных выделенной вершины
        public static Pen data_select_pen = (Pen)Pens.Red.Clone();
        //Кисть для надписей в вершине
        public static SolidBrush brush = (SolidBrush)Brushes.Black.Clone();
        //Цвет кисти для фона вершины
        public static Color brushFone = Color.LightYellow;
        //Свойство для установки стрелки на крандаше
        public static CustomLineCap arrow_prop = initArrowProp();
        //Крандаш для ребра
        public static Pen edge_pen = (Pen)Pens.DarkRed.Clone();
        //Крандаш для ребра со стрелкой
        public static Pen edge_pen_arrow;
        //Крандаш для выделенного ребра со стрелкой
        public static Pen edge_pen_select_arrow;
        //Крандаш для выделенния ребра
        public static Pen edge_pen_select;
        //Создание свойства позволяющего прикреплять стрелки к крандашам
        static private CustomLineCap initArrowProp()
        {
            GraphicsPath Path = new GraphicsPath();

            // Create the outline for our custom end cap.
            Path.AddLine(new PointF(ar_width, -ar_length), new PointF(0, 0));
            Path.AddLine(new PointF(0, 0), new PointF(-ar_width, -ar_length));

            // Construct the arrow end cap.
            return new CustomLineCap(null, Path);
        }
        //инициализация некоторых "сложных" параметров
        static Params()
        {
            edge_pen_arrow = (Pen)Pens.DarkRed.Clone();
            edge_pen_arrow.CustomEndCap = arrow_prop;
            edge_pen_arrow.Width = width;
            edge_pen_select_arrow = (Pen)Pens.Red.Clone();
            edge_pen_select_arrow.CustomEndCap = arrow_prop;
            edge_pen_select_arrow.Width = select_width;
            edge_pen_select = (Pen)Pens.Red.Clone();
            edge_pen_select.Width = select_width + 2;
            data_pen.Width = width;
            data_select_pen.Width = select_width;
        }
    }
}
