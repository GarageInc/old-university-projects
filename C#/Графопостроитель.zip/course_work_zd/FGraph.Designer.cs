﻿namespace course_work_zd
{
    partial class FGraph
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FGraph));
            this.ms_menu = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commandsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addVertexToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.selectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllVerticesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectAllToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.setToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setNameOfVertexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setColorOfVertexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setWeightOfEdgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setColorOfEdgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteSelectedVerticesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteSelectedEdgesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.setVerticesOfTheCircleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.searchOfPathesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.floatLayingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutProgramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createGraphFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tstb_count = new System.Windows.Forms.ToolStripTextBox();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cd_color_of_edge = new System.Windows.Forms.ColorDialog();
            this.cms_vertex = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.setNameOfThisVertexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setColorOfThisVertexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cms_edge = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.setWeightOfThisEdgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setColorOfThisEdgeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ofd_open = new System.Windows.Forms.OpenFileDialog();
            this.sfd_save = new System.Windows.Forms.SaveFileDialog();
            this.pn_managed = new System.Windows.Forms.Panel();
            this.bt_right = new System.Windows.Forms.Button();
            this.bt_down = new System.Windows.Forms.Button();
            this.bt_up = new System.Windows.Forms.Button();
            this.bt_left = new System.Windows.Forms.Button();
            this.lb_scroll_info = new System.Windows.Forms.Label();
            this.ms_menu.SuspendLayout();
            this.cms_vertex.SuspendLayout();
            this.cms_edge.SuspendLayout();
            this.pn_managed.SuspendLayout();
            this.SuspendLayout();
            // 
            // ms_menu
            // 
            this.ms_menu.BackColor = System.Drawing.SystemColors.Control;
            this.ms_menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.commandsToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.createGraphFromToolStripMenuItem,
            this.tstb_count,
            this.infoToolStripMenuItem});
            this.ms_menu.Location = new System.Drawing.Point(0, 0);
            this.ms_menu.Name = "ms_menu";
            this.ms_menu.Size = new System.Drawing.Size(624, 27);
            this.ms_menu.TabIndex = 0;
            this.ms_menu.Text = "menuStrip1";
            this.ms_menu.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            this.ms_menu.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(48, 23);
            this.fileToolStripMenuItem.Text = "Файл";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.newToolStripMenuItem.Text = "Новый";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.openToolStripMenuItem.Text = "Открыть";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.saveToolStripMenuItem.Text = "Сохранить как";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(150, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.exitToolStripMenuItem.Text = "Выход";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // commandsToolStripMenuItem
            // 
            this.commandsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.selectToolStripMenuItem,
            this.setToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.toolStripSeparator4,
            this.setVerticesOfTheCircleToolStripMenuItem,
            this.toolStripSeparator6,
            this.searchOfPathesToolStripMenuItem,
            this.toolStripSeparator3,
            this.floatLayingToolStripMenuItem});
            this.commandsToolStripMenuItem.Name = "commandsToolStripMenuItem";
            this.commandsToolStripMenuItem.Size = new System.Drawing.Size(70, 23);
            this.commandsToolStripMenuItem.Text = "Команды";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addVertexToolStripMenuItem1});
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.addToolStripMenuItem.Text = "Добавление";
            // 
            // addVertexToolStripMenuItem1
            // 
            this.addVertexToolStripMenuItem1.Name = "addVertexToolStripMenuItem1";
            this.addVertexToolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.addVertexToolStripMenuItem1.Text = "Добавить вершину";
            this.addVertexToolStripMenuItem1.Click += new System.EventHandler(this.addVertexToolStripMenuItem_Click);
            // 
            // selectToolStripMenuItem
            // 
            this.selectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectAllToolStripMenuItem,
            this.selectAllVerticesToolStripMenuItem,
            this.selectAllToolStripMenuItem1});
            this.selectToolStripMenuItem.Name = "selectToolStripMenuItem";
            this.selectToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.selectToolStripMenuItem.Text = "Выделение";
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.selectAllToolStripMenuItem.Text = "Выделить все ребра";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllEdgesToolStripMenuItem_Click);
            // 
            // selectAllVerticesToolStripMenuItem
            // 
            this.selectAllVerticesToolStripMenuItem.Name = "selectAllVerticesToolStripMenuItem";
            this.selectAllVerticesToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.selectAllVerticesToolStripMenuItem.Text = "Выделить все вершины";
            this.selectAllVerticesToolStripMenuItem.Click += new System.EventHandler(this.selectAllVerticesToolStripMenuItem_Click);
            // 
            // selectAllToolStripMenuItem1
            // 
            this.selectAllToolStripMenuItem1.Name = "selectAllToolStripMenuItem1";
            this.selectAllToolStripMenuItem1.Size = new System.Drawing.Size(204, 22);
            this.selectAllToolStripMenuItem1.Text = "Выделить всё";
            this.selectAllToolStripMenuItem1.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // setToolStripMenuItem
            // 
            this.setToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setNameOfVertexToolStripMenuItem,
            this.setColorOfVertexToolStripMenuItem,
            this.setWeightOfEdgeToolStripMenuItem,
            this.setColorOfEdgeToolStripMenuItem});
            this.setToolStripMenuItem.Name = "setToolStripMenuItem";
            this.setToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.setToolStripMenuItem.Text = "Изменение";
            // 
            // setNameOfVertexToolStripMenuItem
            // 
            this.setNameOfVertexToolStripMenuItem.Name = "setNameOfVertexToolStripMenuItem";
            this.setNameOfVertexToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.setNameOfVertexToolStripMenuItem.Text = "Назначить вершине имя";
            this.setNameOfVertexToolStripMenuItem.Click += new System.EventHandler(this.SetNameOfVertexToolStripMenuItem_Click);
            // 
            // setColorOfVertexToolStripMenuItem
            // 
            this.setColorOfVertexToolStripMenuItem.Name = "setColorOfVertexToolStripMenuItem";
            this.setColorOfVertexToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.setColorOfVertexToolStripMenuItem.Text = "Назначить вершине цвет";
            this.setColorOfVertexToolStripMenuItem.Click += new System.EventHandler(this.setColorOfVertexToolStripMenuItem_Click);
            // 
            // setWeightOfEdgeToolStripMenuItem
            // 
            this.setWeightOfEdgeToolStripMenuItem.Name = "setWeightOfEdgeToolStripMenuItem";
            this.setWeightOfEdgeToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.setWeightOfEdgeToolStripMenuItem.Text = "Назначить ребру вес";
            this.setWeightOfEdgeToolStripMenuItem.Click += new System.EventHandler(this.SetWeightOfEdgeToolStripMenuItem_Click);
            // 
            // setColorOfEdgeToolStripMenuItem
            // 
            this.setColorOfEdgeToolStripMenuItem.Name = "setColorOfEdgeToolStripMenuItem";
            this.setColorOfEdgeToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.setColorOfEdgeToolStripMenuItem.Text = "Назначить ребру цвет";
            this.setColorOfEdgeToolStripMenuItem.Click += new System.EventHandler(this.setColorOfEdgeToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteSelectedVerticesToolStripMenuItem,
            this.deleteSelectedEdgesToolStripMenuItem,
            this.deleteAllToolStripMenuItem});
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.deleteToolStripMenuItem.Text = "Удаление";
            // 
            // deleteSelectedVerticesToolStripMenuItem
            // 
            this.deleteSelectedVerticesToolStripMenuItem.Name = "deleteSelectedVerticesToolStripMenuItem";
            this.deleteSelectedVerticesToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.deleteSelectedVerticesToolStripMenuItem.Text = "Удалить выделенные вершины";
            this.deleteSelectedVerticesToolStripMenuItem.Click += new System.EventHandler(this.deleteSelectedVertexToolStripMenuItem_Click);
            // 
            // deleteSelectedEdgesToolStripMenuItem
            // 
            this.deleteSelectedEdgesToolStripMenuItem.Name = "deleteSelectedEdgesToolStripMenuItem";
            this.deleteSelectedEdgesToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.deleteSelectedEdgesToolStripMenuItem.Text = "Удалить выделенные ребра";
            this.deleteSelectedEdgesToolStripMenuItem.Click += new System.EventHandler(this.deleteSelectedEdgesToolStripMenuItem_Click);
            // 
            // deleteAllToolStripMenuItem
            // 
            this.deleteAllToolStripMenuItem.Name = "deleteAllToolStripMenuItem";
            this.deleteAllToolStripMenuItem.Size = new System.Drawing.Size(246, 22);
            this.deleteAllToolStripMenuItem.Text = "Удалить всё, что выделено";
            this.deleteAllToolStripMenuItem.Click += new System.EventHandler(this.deleteAllSelectedToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(175, 6);
            // 
            // setVerticesOfTheCircleToolStripMenuItem
            // 
            this.setVerticesOfTheCircleToolStripMenuItem.Name = "setVerticesOfTheCircleToolStripMenuItem";
            this.setVerticesOfTheCircleToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.setVerticesOfTheCircleToolStripMenuItem.Text = "Вершины по кругу";
            this.setVerticesOfTheCircleToolStripMenuItem.Click += new System.EventHandler(this.setVerticesOfTheCircleToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(175, 6);
            // 
            // searchOfPathesToolStripMenuItem
            // 
            this.searchOfPathesToolStripMenuItem.Name = "searchOfPathesToolStripMenuItem";
            this.searchOfPathesToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.searchOfPathesToolStripMenuItem.Text = "Искать пути";
            this.searchOfPathesToolStripMenuItem.Click += new System.EventHandler(this.searchOfPathesToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(175, 6);
            // 
            // floatLayingToolStripMenuItem
            // 
            this.floatLayingToolStripMenuItem.Name = "floatLayingToolStripMenuItem";
            this.floatLayingToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.floatLayingToolStripMenuItem.Text = "Плоская укладка";
            this.floatLayingToolStripMenuItem.Click += new System.EventHandler(this.floatLayingToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manualToolStripMenuItem,
            this.toolStripSeparator2,
            this.aboutProgramToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(68, 23);
            this.helpToolStripMenuItem.Text = "Помощь";
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.manualToolStripMenuItem.Text = "Управление";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(146, 6);
            // 
            // aboutProgramToolStripMenuItem
            // 
            this.aboutProgramToolStripMenuItem.Name = "aboutProgramToolStripMenuItem";
            this.aboutProgramToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.aboutProgramToolStripMenuItem.Text = "О программе";
            this.aboutProgramToolStripMenuItem.Click += new System.EventHandler(this.aboutProgramToolStripMenuItem_Click);
            // 
            // createGraphFromToolStripMenuItem
            // 
            this.createGraphFromToolStripMenuItem.Name = "createGraphFromToolStripMenuItem";
            this.createGraphFromToolStripMenuItem.Size = new System.Drawing.Size(101, 23);
            this.createGraphFromToolStripMenuItem.Text = "Создать граф с";
            this.createGraphFromToolStripMenuItem.Click += new System.EventHandler(this.createGraphFromToolStripMenuItem_Click);
            // 
            // tstb_count
            // 
            this.tstb_count.Name = "tstb_count";
            this.tstb_count.Size = new System.Drawing.Size(50, 23);
            this.tstb_count.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tstb_count.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            this.tstb_count.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(85, 23);
            this.infoToolStripMenuItem.Text = "вершинами";
            // 
            // cms_vertex
            // 
            this.cms_vertex.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setNameOfThisVertexToolStripMenuItem,
            this.setColorOfThisVertexToolStripMenuItem});
            this.cms_vertex.Name = "cms_vertex";
            this.cms_vertex.Size = new System.Drawing.Size(241, 48);
            // 
            // setNameOfThisVertexToolStripMenuItem
            // 
            this.setNameOfThisVertexToolStripMenuItem.Name = "setNameOfThisVertexToolStripMenuItem";
            this.setNameOfThisVertexToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.setNameOfThisVertexToolStripMenuItem.Text = "Назначить имя этой вершине";
            this.setNameOfThisVertexToolStripMenuItem.Click += new System.EventHandler(this.setNameOfThisVertexToolStripMenuItem_Click);
            // 
            // setColorOfThisVertexToolStripMenuItem
            // 
            this.setColorOfThisVertexToolStripMenuItem.Name = "setColorOfThisVertexToolStripMenuItem";
            this.setColorOfThisVertexToolStripMenuItem.Size = new System.Drawing.Size(240, 22);
            this.setColorOfThisVertexToolStripMenuItem.Text = "Назначить цвет этой вершине";
            this.setColorOfThisVertexToolStripMenuItem.Click += new System.EventHandler(this.setColorOfThisVertexToolStripMenuItem_Click);
            // 
            // cms_edge
            // 
            this.cms_edge.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setWeightOfThisEdgeToolStripMenuItem,
            this.setColorOfThisEdgeToolStripMenuItem});
            this.cms_edge.Name = "cms_edge";
            this.cms_edge.Size = new System.Drawing.Size(229, 48);
            // 
            // setWeightOfThisEdgeToolStripMenuItem
            // 
            this.setWeightOfThisEdgeToolStripMenuItem.Name = "setWeightOfThisEdgeToolStripMenuItem";
            this.setWeightOfThisEdgeToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.setWeightOfThisEdgeToolStripMenuItem.Text = "Назначить вес этого ребра";
            this.setWeightOfThisEdgeToolStripMenuItem.Click += new System.EventHandler(this.setWeightOfThisEdgeToolStripMenuItem_Click);
            // 
            // setColorOfThisEdgeToolStripMenuItem
            // 
            this.setColorOfThisEdgeToolStripMenuItem.Name = "setColorOfThisEdgeToolStripMenuItem";
            this.setColorOfThisEdgeToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.setColorOfThisEdgeToolStripMenuItem.Text = "Назначить цвет этого ребра";
            this.setColorOfThisEdgeToolStripMenuItem.Click += new System.EventHandler(this.setColorOfThisEdgeToolStripMenuItem_Click);
            // 
            // ofd_open
            // 
            this.ofd_open.Filter = "файлы графов|*.graph|Все файлы|*.*";
            // 
            // sfd_save
            // 
            this.sfd_save.Filter = "файлы графов|*.graph|Все файлы|*.*";
            // 
            // pn_managed
            // 
            this.pn_managed.BackColor = System.Drawing.SystemColors.Control;
            this.pn_managed.Controls.Add(this.bt_right);
            this.pn_managed.Controls.Add(this.bt_down);
            this.pn_managed.Controls.Add(this.bt_up);
            this.pn_managed.Controls.Add(this.bt_left);
            this.pn_managed.Controls.Add(this.lb_scroll_info);
            this.pn_managed.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pn_managed.Location = new System.Drawing.Point(0, 311);
            this.pn_managed.Name = "pn_managed";
            this.pn_managed.Size = new System.Drawing.Size(624, 30);
            this.pn_managed.TabIndex = 2;
            // 
            // bt_right
            // 
            this.bt_right.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_right.Location = new System.Drawing.Point(541, 3);
            this.bt_right.Name = "bt_right";
            this.bt_right.Size = new System.Drawing.Size(56, 23);
            this.bt_right.TabIndex = 4;
            this.bt_right.Text = "Вправо";
            this.bt_right.UseVisualStyleBackColor = true;
            this.bt_right.Click += new System.EventHandler(this.bt_right_Click);
            this.bt_right.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            this.bt_right.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            // 
            // bt_down
            // 
            this.bt_down.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_down.Location = new System.Drawing.Point(485, 3);
            this.bt_down.Name = "bt_down";
            this.bt_down.Size = new System.Drawing.Size(50, 23);
            this.bt_down.TabIndex = 3;
            this.bt_down.Text = "Вниз";
            this.bt_down.UseVisualStyleBackColor = true;
            this.bt_down.Click += new System.EventHandler(this.bt_down_Click);
            this.bt_down.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            this.bt_down.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            // 
            // bt_up
            // 
            this.bt_up.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_up.Location = new System.Drawing.Point(429, 3);
            this.bt_up.Name = "bt_up";
            this.bt_up.Size = new System.Drawing.Size(50, 23);
            this.bt_up.TabIndex = 2;
            this.bt_up.Text = "Вверх";
            this.bt_up.UseVisualStyleBackColor = true;
            this.bt_up.Click += new System.EventHandler(this.bt_up_Click);
            this.bt_up.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            this.bt_up.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            // 
            // bt_left
            // 
            this.bt_left.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_left.Location = new System.Drawing.Point(373, 3);
            this.bt_left.Name = "bt_left";
            this.bt_left.Size = new System.Drawing.Size(50, 23);
            this.bt_left.TabIndex = 1;
            this.bt_left.Text = "Влево";
            this.bt_left.UseVisualStyleBackColor = true;
            this.bt_left.Click += new System.EventHandler(this.bt_left_Click);
            this.bt_left.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            this.bt_left.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            // 
            // lb_scroll_info
            // 
            this.lb_scroll_info.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_scroll_info.AutoSize = true;
            this.lb_scroll_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_scroll_info.Location = new System.Drawing.Point(191, 6);
            this.lb_scroll_info.Name = "lb_scroll_info";
            this.lb_scroll_info.Size = new System.Drawing.Size(167, 20);
            this.lb_scroll_info.TabIndex = 0;
            this.lb_scroll_info.Text = "Прокрутка картинки:";
            // 
            // FGraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(624, 341);
            this.Controls.Add(this.pn_managed);
            this.Controls.Add(this.ms_menu);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.ms_menu;
            this.MinimumSize = new System.Drawing.Size(400, 300);
            this.Name = "FGraph";
            this.Text = "Graph Bilder v 3.0 - noname.graph";
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.FGraph_MouseUp);
            this.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.FGraph_MouseDoubleClick);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.FGraph_Paint);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FGraph_MouseClick);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FGraph_MouseDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyUp);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FGraph_MouseMove);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FGraph_KeyDown);
            this.ms_menu.ResumeLayout(false);
            this.ms_menu.PerformLayout();
            this.cms_vertex.ResumeLayout(false);
            this.cms_edge.ResumeLayout(false);
            this.pn_managed.ResumeLayout(false);
            this.pn_managed.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip ms_menu;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem commandsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem aboutProgramToolStripMenuItem;
        private System.Windows.Forms.ColorDialog cd_color_of_edge;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem setVerticesOfTheCircleToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip cms_vertex;
        private System.Windows.Forms.ContextMenuStrip cms_edge;
        private System.Windows.Forms.ToolStripMenuItem setNameOfThisVertexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setWeightOfThisEdgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setColorOfThisEdgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem searchOfPathesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setColorOfThisVertexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createGraphFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox tstb_count;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog ofd_open;
        private System.Windows.Forms.SaveFileDialog sfd_save;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteSelectedVerticesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addVertexToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deleteSelectedEdgesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllVerticesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem setToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setNameOfVertexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setColorOfVertexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setWeightOfEdgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setColorOfEdgeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem floatLayingToolStripMenuItem;
        private System.Windows.Forms.Panel pn_managed;
        private System.Windows.Forms.Button bt_right;
        private System.Windows.Forms.Button bt_down;
        private System.Windows.Forms.Button bt_up;
        private System.Windows.Forms.Button bt_left;
        private System.Windows.Forms.Label lb_scroll_info;

    }
}

